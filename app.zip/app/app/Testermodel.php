<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Testermodel extends Model
{
    //
}
