<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class peruntukandonasi extends Model
{
    //
    protected $table = 'peruntukandonasi';
    protected $fillable = ['namaperuntukandonasi', 'statusaktif'];


    // function semua()

}
