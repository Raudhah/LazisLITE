<!-- // amil -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Hapus Amil'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Amil'); ?>

<?php $__env->startSection('modulsection', 'Hapus'); ?>
<?php $__env->startSection('modulicon', 'fa fa-trash'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Hapus Amil'); ?>

<?php $__env->startSection('boxheader-instruction', 'Apakah Yakin Anda Mau Menghapus Data Berikut?'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<!-- form start -->
<form class="form-horizontal" method="POST" action="/amil/<?php echo e($data->id); ?>">
<?php echo e(@csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>


     

        <table class="table table-striped">
            <thead>
                <tr>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nama Amil</th>
                    <td><?php echo e($data->namaamil); ?></td>
                </tr>

                <tr>
                    <th>Alamat Amil</th>
                    <td><?php echo e($data->alamatamil); ?></td>
                </tr>

                <tr>
                    <th>Nomor Telepon Amil</th>
                    <td><?php echo e($data->nomorteleponamil); ?></td>
                </tr>
                

                <tr>
                    <th>Status</th>
                    <td>
                        <?php if($data->statusaktif): ?>
                            Aktif
                        <?php else: ?>
                            Non-Aktif
                        <?php endif; ?>
    
                    </td>
                </tr>
            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-danger btn-lg">HAPUS Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>