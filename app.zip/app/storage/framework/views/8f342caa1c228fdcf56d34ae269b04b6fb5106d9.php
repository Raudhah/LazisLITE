<!-- // trxdonasi -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Cetak Kuitansi'); ?>


<!-- //========== HEADER KUITANSI ======== -->
<!-- //========== logo, alamat, dkk ditaruh disini ya ======== -->
<?php $__env->startSection('headerkuitansi'); ?>
<div class="row">
        <div class="col-sm-3">
                <img src="<?php echo e(asset('img/logolaz.png')); ?>" width="100"/>
        </div>
        <div class="col-sm-6">
                LAZ Baitul Maal Abdurrahman Bin Auf (LAZ ABA)
                <br/>
        </div>
        <div class="col-sm-3" style="text-align:right">
                <small>
                    No. : INFQ-<?php echo e($idtransaksi); ?>

                </small>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('nomorkuitansi'); ?>
   
<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KIRI KUITANSI ======== -->
<?php $__env->startSection('kolomkiri'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->namadonatur); ?></td>
                </tr>
                <tr>
                    <th>Almat Donatur</th>
                    <td><?php echo e($datadonatur->alamatdonatur); ?></td>
                </tr>
                <tr>
                    <th>Nomor Telepon Donatur</th>
                    <td><?php echo e($datadonatur->nomortelepondonatur); ?></td>
                </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KANAN KUITANSI ======== -->
<?php $__env->startSection('kolomkanan'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                    
                    <tr>
                        <th>Petugas AMIL</th>
                        <td><a href="/amil/<?php echo e($dataamil->id); ?>"><?php echo e($dataamil->namaamil); ?></a></td>
                    </tr>
        
                    
                    <tr>
                        <th>Tanggal </th>
                        <td><?php echo e($tanggaldonasi); ?></td>
                    </tr>
        
        </tbody>

    </table>


<?php $__env->stopSection(); ?>

<!-- //========== RINCIAN KUITANSI ======== -->
<?php $__env->startSection('rinciankuitansi'); ?>

        <blockquote>
            Alhamdulillah, telah diterima dari hasil perolehan Kotak Infaq Pada Tanggal <?php echo e($tanggaldonasi); ?> Kotak Infaq
            Sebesar <strong>Rp.<?php echo e(number_format($jumlahtotal,0,',','.')); ?>,00</strong>
            <small><em>Semoga ALLAH memberi pahala atas apa yang Anda berikan, <br/> memberikan barokah atas apa yang masih di tangan Anda, <br/> dan menjadikannya sebagai pembersih Anda</em></small>
        </blockquote>

<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('kolombawahkiri'); ?>
    
    
    <div class="bg-gray">
        Keterangan : 
        <?php echo e($keterangan); ?>

        <br/>
        
    </div>

    <br/>
    <br/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('kolombawahkanan'); ?>
    TANDA TANGAN DISINI
<?php $__env->stopSection(); ?>


<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>



<?php echo $__env->make('master.layoutkuitansi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>