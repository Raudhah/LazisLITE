<?php echo $__env->make("master/header1", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <title><?php echo $__env->yieldContent('appname', env('APP_NAME')); ?> | <?php echo $__env->yieldContent('pagename'); ?></title>


    <?php echo $__env->make("master/header2", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <?php echo $__env->yieldContent('headertag', ""); ?>


    <?php echo $__env->make("master/menu/top", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if(auth::user()->levelakses == 1): ?>
  <?php echo $__env->make("master/menu/side", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>    
<?php else: ?>
  <?php echo $__env->make("master/menu/sidesuperadmin", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endif; ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        
        <?php echo $__env->yieldContent('modulname', env('APP_NAME')); ?>

        <small><?php echo $__env->yieldContent('modulsection'); ?></small>
      </h1>

      <!-- THIS IS THE BREADCRUMB -->
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Dashboard</li>
      </ol>


    </section>


    <section class="content">

      <!-- Main row -->
      <div class="row">
        <!-- Left col -->
        <section class="col-lg-12 connectedSortable">
          <!-- Custom tabs (Charts with tabs)-->
          <div class="nav-tabs-custom">
            <!-- Tabs within a box -->
            <ul class="nav nav-tabs pull-right">
                <li class="pull-left header">

                    <i class="<?php echo $__env->yieldContent('modulicon', 'fa fa-inbox'); ?>"></i>

                    <?php echo $__env->yieldContent('boxheader-title','LazisLITE'); ?>

                </li>
            </ul>
            
            <div class="tab-content ">

              <div class="box box-info">
                
                <div class="box-header with-border">
                    <h4 class="box-title">
                      <?php echo $__env->yieldContent('boxheader-instruction', 'Instruksi bla bla'); ?> 
                    </h4>
                </div>





                <!-- /.box-header -->
            
                <div class="box-body">

                    <?php echo $__env->yieldContent('boxmessage'); ?>

                    <?php echo $__env->yieldContent('boxcontent'); ?>

                </div>
                <!-- /box-body -->

                
                <div class="box-footer">

                    <?php echo $__env->yieldContent('boxfooter'); ?>

                </div>
                <!-- /box-footer -->




              </div>
              <!-- /box box-info-->
              
            </div>

            <!-- tab-content -->
          </div>
          <!-- /.nav-tabs-custom -->



        </section>
        <!-- /.Left col -->
        
        
      </div>
      <!-- /.row (main row) -->

    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

    <?php echo $__env->make("master/footer", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>