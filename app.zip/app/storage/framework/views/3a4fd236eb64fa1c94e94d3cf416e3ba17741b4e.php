<!-- // dashboard -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Data Dashboard'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Dashboard'); ?>

<?php $__env->startSection('modulsection', 'Tampilkan'); ?>
<?php $__env->startSection('modulicon', 'fa fa-list'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Tampilkan Data Dashboard'); ?>

<?php $__env->startSection('boxheader-instruction', 'Hanya Dashboard dengan status "aktif" yang muncul saat Transaksi / Tambah Donatur'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>

<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>
    <div class="box"><h1>Ini adalah Dashboard</h1></div>

<?php $__env->stopSection(); ?>



<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>