<!-- // trxdonasi -->





<!-- //========== HEADER KUITANSI ======== -->
<!-- //========== logo, alamat, dkk ditaruh disini ya ======== -->
<?php $__env->startSection('headerkuitansi'); ?>

    <div class="row">
        <div class="col-sm-3">
                <img src="<?php echo e(asset('img/logolaz.png')); ?>" width="100"/>
        </div>
        <div class="col-sm-6">
                LAZ Baitul Maal Abdurrahman Bin Auf (LAZ ABA)
                <br/>
        </div>
        <div class="col-sm-3" style="text-align:right">
                <small>
                    No. : IBRK-<?php echo e($idtransaksi); ?>

                </small>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('nomorkuitansi'); ?>
   
<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KIRI KUITANSI ======== -->
<?php $__env->startSection('kolomkiri'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->namadonatur); ?></td>
                </tr>
                <tr>
                    <th>Almat Donatur</th>
                    <td><?php echo e($datadonatur->alamatdonatur); ?></td>
                </tr>
                <tr>
                    <th>Nomor Telepon Donatur</th>
                    <td><?php echo e($datadonatur->nomortelepondonatur); ?></td>
                </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KANAN KUITANSI ======== -->
<?php $__env->startSection('kolomkanan'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                    
                    <tr>
                        <th>Petugas AMIL</th>
                        <td><a href="/amil/<?php echo e($dataamil->id); ?>"><?php echo e($dataamil->namaamil); ?></a></td>
                    </tr>
        
                    
                    <tr>
                        <th>Tanggal </th>
                        <td><?php echo e($tanggaldonasi); ?></td>
                    </tr>
        
        </tbody>

    </table>


<?php $__env->stopSection(); ?>

<!-- //========== RINCIAN KUITANSI ======== -->
<?php $__env->startSection('rinciankuitansi'); ?>

        <blockquote>
            Alhamdulillah, telah diterima Pada Tanggal <?php echo e($tanggaldonasi); ?>  <br/>
            Donasi berupa <strong><?php echo e($deskripsibarang); ?></strong>
            <small><em>Semoga ALLAH memberi pahala atas apa yang Anda berikan, <br/> memberikan barokah atas apa yang masih di tangan Anda, <br/> dan menjadikannya sebagai pembersih Anda</em></small>
        </blockquote>

<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('kolombawahkiri'); ?>
    
    
    <br/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('kolombawahkanan'); ?>
    TANDA TANGAN DISINI
<?php $__env->stopSection(); ?>


<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>




<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

     

        <table class="table table-striped">
            <thead>
                <tr>
                    <th width="30%">KEY</th>
                    <th>VALUE</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->namadonatur); ?></td>
                </tr>
                <tr>
                    <th>Almat Donatur</th>
                    <td><?php echo e($datadonatur->alamatdonatur); ?></td>
                </tr>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->nomortelepondonatur); ?></td>
                </tr>
                
                <tr>
                    <th>Petugas AMIL</th>
                    <td><a class="btn btn-success" href="/amil/<?php echo e($dataamil->id); ?>"><?php echo e($dataamil->namaamil); ?></a></td>
                </tr>

                
                <tr>
                    <th>Tanggal Donasi</th>
                    <td><?php echo e($tanggaldonasi); ?></td>
                </tr>

                <tr>
                    <th>Deskripsi Barang</th>
                    <td><?php echo e($deskripsibarang); ?></td>
                </tr>

                <tr>
                    <th>Nominal Valuasi</th>
                    <td><?php echo e(number_format($nominalvaluasi,0,',','.')); ?></td>
                </tr>
                
                <tr>
                    <th>Peruntukan Donasi</th>
                    <td><a class="btn btn-primary" href="#"><?php echo e($dataperuntukandonasi->namaperuntukandonasi); ?></a></td>
                </tr>
                

            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <a class="btn btn-warning" href="/trxibrankasku/<?php echo e($idtransaksi); ?>/edit">Edit</a>
            <a class="btn btn-danger" href="/trxibrankasku/<?php echo e($idtransaksi); ?>/delete">Hapus</a>
        </div>
    

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutkuitansi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>