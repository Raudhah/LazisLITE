<!-- // trxdonasi -->




<?php $__env->startSection('pagename'); ?>
    Cetak Kuitansi
<?php $__env->stopSection(); ?>


<!-- //========== HEADER KUITANSI ======== -->
<!-- //========== logo, alamat, dkk ditaruh disini ya ======== -->
<?php $__env->startSection('headerkuitansi'); ?>
<div class="row">
        <div class="col-sm-3">
                <img src="<?php echo e(asset('img/'.$konfig->namafilelogo)); ?>" width="100"/>
        </div>
        <div class="col-sm-6">
                <?php echo e($konfig->namacabang); ?>

                <br/>

                <small>

                    <?php echo e($konfig->alamatcabang); ?>


                </small>
        </div>
        <div class="col-sm-3" style="text-align:right">
                <small>
                    No. : DNS-<?php echo e($idtransaksi); ?>

                </small>
        </div>
    </div>



<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('nomorkuitansi'); ?>
<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KIRI KUITANSI ======== -->
<?php $__env->startSection('kolomkiri'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->namadonatur); ?></td>
                </tr>
                <tr>
                    <th>Almat Donatur</th>
                    <td><?php echo e($datadonatur->alamatdonatur); ?></td>
                </tr>
                <tr>
                    <th>Nomor Telepon Donatur</th>
                    <td><?php echo e($datadonatur->nomortelepondonatur); ?></td>
                </tr>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>

<!-- //========== KOLOM KANAN KUITANSI ======== -->
<?php $__env->startSection('kolomkanan'); ?>
    
    <table class="table table-condensed no-border">
        <tbody>
                <tr>
                        <th>Jenis Donasi</th>
                        <td>
                            <?php echo e(($insidentil==0 ? "Donasi Rutin":"Donasi Insidentil")); ?>

                        </td>
                    </tr>
                    
                    <tr>
                        <th>Petugas AMIL</th>
                        <td><a href="/amil/<?php echo e($dataamil->id); ?>"><?php echo e($dataamil->namaamil); ?></a></td>
                    </tr>
        
                    
                    <tr>
                        <th>Tanggal Donasi</th>
                        <td><?php echo e($tanggaldonasi); ?></td>
                    </tr>
        
        </tbody>

    </table>


<?php $__env->stopSection(); ?>

<!-- //========== RINCIAN KUITANSI ======== -->
<?php $__env->startSection('rinciankuitansi'); ?>

            <table class="table table-striped">
                    <thead>
                        <tr class="bg-primary">
                            <th>Nomor</th>
                            <th>Peruntukan Donasi</th>
                            <th class="">Jumlah</th>
                        </tr>
                    </thead>
                
                    <tbody>
                        <!- // PERINCIANNYA-->
                        <?php $__currentLoopData = $listtrxdonasidetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trxdonasidetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td><?php echo e(++$key); ?></td>
                                <td><?php echo e($trxdonasidetail->peruntukandonasi->namaperuntukandonasi); ?></td>
                                <td class="pull-right"><?php echo e(number_format($trxdonasidetail->jumlah,0,',','.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <!- // JUMLAH TOTALNYA-->
                            <tr>
                                <td class=""></td>
                                <td class=""><strong> JUMLAH TOTAL</strong></td>
                                <td class="pull-right"><strong><?php echo e(number_format($jumlahtotal,0,',','.')); ?></strong></td>
                            </tr>
                            
                    </tbody>
        
            </table>

<?php $__env->stopSection(); ?>

<!-- //========== NOMOR KUITANSI ======== -->
<?php $__env->startSection('kolombawahkiri'); ?>
    
    
    <div class="bg-gray">
        Keterangan : 
        <?php echo e($keterangan); ?>

    </div>
    <br/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('kolombawahkanan'); ?>
    TANDA TANGAN DISINI
<?php $__env->stopSection(); ?>


<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutkuitansi', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>