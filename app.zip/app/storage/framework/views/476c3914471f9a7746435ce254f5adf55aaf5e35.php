<?php echo $__env->make("master/header1", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  
    <title><?php echo $__env->yieldContent('appname', env('APP_NAME')); ?> | <?php echo $__env->yieldContent('pagename'); ?></title>


    <?php echo $__env->make("master/header2blank", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="wrapper">
      <!-- Main content -->

      <section class="invoice">
        <?php echo $__env->yieldContent('boxcontent'); ?>
      </section>


    </div>




<?php echo $__env->make("master/footerblank", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>