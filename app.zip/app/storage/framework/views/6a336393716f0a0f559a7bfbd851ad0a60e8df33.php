<!-- // peruntukan donasi -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Edit Peruntukan Donasi'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Peruntukan Donasi'); ?>

<?php $__env->startSection('modulsection', 'Edit'); ?>
<?php $__env->startSection('modulicon', 'fa fa-pencil'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Edit Peruntukan Donasi'); ?>

<?php $__env->startSection('boxheader-instruction', 'Edit form berikut. Tanda * wajib diisi'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<!-- form start -->
<form class="form-horizontal" method="POST" action="/peruntukandonasi/<?php echo e($data->id); ?>">
<?php echo e(@csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


        <div class="form-group">
            <label for="namaperuntukandonasi" class="col-sm-2 control-label input-lg">
                Nama Peruntukan Donasi *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namaperuntukandonasi" id="namaperuntukandonasi" placeholder="Nama Peruntukan Donasi (misal : zakat, wakaf, program yatim, program Pondok Lansia, )" value="<?php echo e($data->namaperuntukandonasi); ?>" required>
            </div>

        </div>

        <div class="form-group">
            <label for="statusaktif" class="col-sm-2 control-label input-lg">
                Status Aktif
            </label>

            <div class="col-sm-10">

                    <?php 
                        $aktif = $nonaktif = "";
                    ?>

                    <?php if($data->statusaktif): ?>
                        <?php $aktif = "checked" ?>
                    <?php else: ?>
                        <?php $nonaktif = "checked"; ?>
                    <?php endif; ?>

                    <label class="input-lg">
                        <input type="radio" name="statusaktif" <?php echo e($aktif); ?> value="1"> Aktif 
                    </label>
                    <label class="input-lg">
                        <input type="radio" name="statusaktif" <?php echo e($nonaktif); ?> value='0'> Non-Aktif
                    </label>
            </div>

        </div>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-info btn-lg">UPDATE Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>