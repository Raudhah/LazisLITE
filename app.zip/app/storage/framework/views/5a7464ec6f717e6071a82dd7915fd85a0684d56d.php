<!-- // pekerjaan donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Tambah Donatur'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Donatur'); ?>

<?php $__env->startSection('modulsection', 'Tambah'); ?>
<?php $__env->startSection('modulicon', 'fa fa-plus'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Tambah Donatur'); ?>

<?php $__env->startSection('boxheader-instruction', 'Isi form berikut. Tanda * wajib diisi. '); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>


<!-- form start -->
<form class="form-horizontal" method="POST" action="/donatur">
<?php echo e(@csrf_field()); ?>


        <!-- // Nama Donatur -->
        <div class="form-group">
            <label for="namadonatur" class="col-sm-2 control-label input-lg">
                Nama Donatur *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namadonatur" value="<?php echo e(old('namadonatur')); ?>" id="namadonatur" placeholder="Nama Donatur" required>
            </div>
        </div>

        <!-- // Jenis Donatur -->
        <div class="form-group">

            <label class="col-sm-2 control-label input-lg">
                Jenis Donatur*
            </label>
            
            <div class="col-sm-10">
                <label class="input-lg">
                    <input type="checkbox" name="isdonaturrutin" value="1"> Donatur Rutin
                </label>
                <label class="input-lg">
                    <input type="checkbox" name="iskotakinfaq" value="1"> Kotak Infaq
                </label>
                <label class="input-lg">
                    <input type="checkbox" name="isdonaturinsidental" value="1"> Donatur Insidental
                </label>
            </div>
        </div>


        <!-- //AMil yang bertanggung Jawab -->
        <div class="form-group">
            <label for="amil_id" class="col-sm-2 control-label input-lg">
                Petugas Amil* 
            </label>

            <div class="col-sm-10">
                <select name="amil_id" id="amil_id" class="form-control input-lg">
                    <?php $__currentLoopData = $listamil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $amil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if(old('amil_id') == $amil->id): ?>
                        <option selected="selected" value="<?php echo e($amil->id); ?>"><?php echo e($amil->namaamil); ?></option>    
                    <?php else: ?>
                        <option value="<?php echo e($amil->id); ?>"><?php echo e($amil->namaamil); ?></option>
                    <?php endif; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

        </div>

        <!-- //NOMOR TELEPON -->
        <div class="form-group">
            <label for="inputnomortelepon" class="col-sm-2 control-label input-lg">
                Nomor Telepon
            </label>

            <div class="col-sm-10">
                <input type="text"  name="nomortelepondonatur"  value="<?php echo e(old('nomortelepondonatur')); ?>" class="form-control input-lg" id="nomortelepondonatur" placeholder="08xxxx...">
            </div>

        </div>
        
        <!-- //ALAMAT DONATUR -->
        <div class="form-group">
            <label for="alamatdonatur" class="col-sm-2 control-label input-lg">
                Alamat Donatur
            </label>

            <div class="col-sm-10">
                <input type="text" name="alamatdonatur"  value="<?php echo e(old('alamatdonatur')); ?>" class="form-control input-lg" id="alamatdonatur" placeholder="Alamat Donatur">
            </div>

        </div>

       
        <!-- //TANGGAL LAHIR DONATUR -->
        <div class="form-group">
            <label for="tanggallahir" class="col-sm-2 control-label input-lg">
                Tanggal Lahir
            </label>

            <div class="col-sm-10">
                <div class="input-group date">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text"  name="tanggallahir" id="tanggallahir" value="<?php echo e(old('tanggallahir', '')); ?>"  class="form-control pull-right" >
                </div>
                <!-- //.input group date -->    
            </div>

        </div>

        <div class="form-group">
            <label for="pekerjaandonatur_id" class="col-sm-2 control-label input-lg">
                Pekerjaan *
            </label>

            <div class="col-sm-10">
                <select name="pekerjaandonatur_id"  id="pekerjaandonatur_id" class="form-control input-lg">
                    
                    <?php $__currentLoopData = $listpekerjaandonatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pekerjaandonatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                        <?php if(old('pekerjaandonatur_id') == $pekerjaandonatur->id): ?>
                            <option selected="selected" value="<?php echo e($pekerjaandonatur->id); ?>"><?php echo e($pekerjaandonatur->namapekerjaandonatur); ?></option>    
                        <?php else: ?>
                            <option value="<?php echo e($pekerjaandonatur->id); ?>"><?php echo e($pekerjaandonatur->namapekerjaandonatur); ?></option>
                        <?php endif; ?>
                    
                        

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

        </div>

        <!-- radio -->
        <div class="form-group">

            <label for="jeniskelamindonatur" class="col-sm-2 control-label input-lg">
                Jenis Kelamin
            </label>
            
            <div class="col-sm-10">
                <label class="input-lg">
                    <input type="radio" name="jeniskelamin" value="1" checked> Laki-Laki
                </label>
                <label class="input-lg">
                    <input type="radio" name="jeniskelamin" value="2"> Perempuan
                </label>
                <label class="input-lg">
                    <input type="radio" name="jeniskelamin" value="3"> Tidak Disebutkan
                </label>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-info btn-lg">Tambah Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    <script>
        //Date picker
        $('#tanggallahir').datepicker({
            
            format : "dd/mm/yyyy",
            setDate : "17/09/1987",
            autoclose: true,
        })
    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>