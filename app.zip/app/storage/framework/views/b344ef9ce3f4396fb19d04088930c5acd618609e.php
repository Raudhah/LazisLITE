<!-- // trxibrankasku -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'HAPUS Transaksi iBrankasku'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'iBrankasku'); ?>

<?php $__env->startSection('modulsection', 'HAPUS'); ?>
<?php $__env->startSection('modulicon', 'fa fa-trash'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'HAPUS iBrankasku'); ?>

<?php $__env->startSection('boxheader-instruction', 'silakan Klik Edit / Hapus untuk mengubah Data'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

     

        <table class="table table-striped">
            <thead>
                <tr>
                    <th width="30%">KEY</th>
                    <th>VALUE</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->namadonatur); ?></td>
                </tr>
                <tr>
                    <th>Almat Donatur</th>
                    <td><?php echo e($datadonatur->alamatdonatur); ?></td>
                </tr>
                <tr>
                    <th>Nama Donatur</th>
                    <td><?php echo e($datadonatur->nomortelepondonatur); ?></td>
                </tr>
                
                <tr>
                    <th>Petugas AMIL</th>
                    <td><a class="btn btn-success" href="/amil/<?php echo e($dataamil->id); ?>"><?php echo e($dataamil->namaamil); ?></a></td>
                </tr>

                
                <tr>
                    <th>Tanggal Donasi</th>
                    <td><?php echo e($tanggaldonasi); ?></td>
                </tr>

                <tr>
                    <th>Deskripsi Barang</th>
                    <td><div><?php echo e($deskripsibarang); ?></div></td>
                </tr>

                <tr>
                    <th>Nominal Valuasi</th>
                    <td><?php echo e(number_format($nominalvaluasi,0,',','.')); ?></td>
                </tr>
                
                <tr>
                    <th>Peruntukan Donasi</th>
                    <td><a class="btn btn-primary" href="/peruntukandonasi/<?php echo e($dataperuntukandonasi->id); ?>"><?php echo e($dataperuntukandonasi->namaperuntukandonasi); ?></a></td>
                </tr>
                

            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">

            <!-- form start -->
            <form class="form-horizontal" method="POST" action="/trxibrankasku/<?php echo e($idtransaksi); ?>">
                
                <?php echo e(@csrf_field()); ?>

                <?php echo e(method_field('DELETE')); ?>

                    
                <button type="submit" class="btn btn-danger">Hapus</button>

            </form>
        </div>
    

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>