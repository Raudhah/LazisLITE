<!-- // donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Data Donatur'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Donatur'); ?>

<?php $__env->startSection('modulsection', 'Tampilkan'); ?>
<?php $__env->startSection('modulicon', 'fa fa-list'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Tampilkan Data Donatur'); ?>

<?php $__env->startSection('boxheader-instruction'); ?>

    Klik Pada tanda <i class="fa fa-search"></i> Untuk Melihat Data lebih detail

<?php $__env->stopSection(); ?>
<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>

<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<table id="tabeldata" class="table table-bordered table-striped">
    <thead>
    <tr>
      <th>No.</th>
      <th>ID</th>
      <th>Nama Donatur</th>
      <th>Alamat</th>
      <th>No. Telepon</th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
    </thead>
    <tbody>


    <?php if($data->count() > 0): ?>
    
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <tr>
            <td><?php echo e(++$key); ?></td>
            <td> <?php echo e(config('app.kodedonatur')); ?><?php echo e($item->id); ?></td>
            <td> <?php echo e($item->namadonatur); ?></td>
            <td> <?php echo e($item->alamatdonatur); ?></td>
            <td> <?php echo e($item->nomortelepondonatur); ?></td>
            <td><a href="/donatur/<?php echo e($item->id); ?>"  data-toggle="tooltip" title="detail"><i class="fa fa-search"></i></a></td>
            <td><a href="/donatur/<?php echo e($item->id); ?>/edit"  data-toggle="tooltip" title="edit data"><i class="fa fa-edit"></i></a></td>
            <td><a href="/donatur/<?php echo e($item->id); ?>/delete" data-toggle="tooltip" title="Hapus data"><i class="fa fa-trash"></i></a></td>
        </tr>
       

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php else: ?>
        <tr>
            <td colspan="4">
                Maaf, Data tidak ditemukan... 
            </td>    
        </tr>

    <?php endif; ?>
    

    </tbody>
</table>



<?php $__env->stopSection(); ?>



<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>


<script>
    $(function () {
      $('#tabeldata').DataTable({
        'paging'      : true,
        'pageLength'  : 50,  
        'lengthChange': true,
        'searching'   : true,
        'ordering'    : true,
        'info'        : true,
        'autoWidth'   : false,
        'language'    : {
            "search"    : "Cari Cepat",
            "lengthMenu": "Tampilkan _MENU_ data"
        }
      });
    })
</script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>