<!-- // donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Hapus Donatur'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Donatur'); ?>

<?php $__env->startSection('modulsection', 'Hapus'); ?>
<?php $__env->startSection('modulicon', 'fa fa-trash'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Hapus Donatur'); ?>

<?php $__env->startSection('boxheader-instruction', 'Apakah Yakin Anda Mau Menghapus Data Berikut?'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<!-- form start -->
<form class="form-horizontal" method="POST" action="/donatur/<?php echo e($data->id); ?>">
<?php echo e(@csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>


     

<table class="table table-striped">
    <thead>
        <tr>
            <th width="30%">KEY</th>
            <th>VALUE</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <th>Nama Donatur</th>
            <td><?php echo e($data->namadonatur); ?></td>
        </tr>
        
        <tr>
            <th>Jenis Donatur</th>
            <td>
                <?php if($data->isdonaturrutin==1): ?>
                    <a href="#" class="btn btn-sm btn-primary"> Donatur Rutin, </a>             
                <?php endif; ?>
                
                <?php if($data->iskotakinfaq): ?>
                    <a href="#" class="btn btn-sm btn-primary"> Kotak Infaq,   </a>            
                <?php endif; ?>
                <?php if($data->isdonaturinsidental): ?>
                    <a href="#" class="btn btn-sm btn-primary"> Donatur Insidental,   </a>            
                <?php endif; ?>

            </td>

        </tr>

        <tr>
            <th>Petugas AMIL</th>
            <td><a class="btn btn-success" href="/amil/<?php echo e($amil->id); ?>"><?php echo e($amil->namaamil); ?></a></td>
        </tr>

        <tr>
            <th>Nomor Telepon Donatur</th>
            <td><?php echo e($data->nomortelepondonatur); ?></td>
        </tr>


        <tr>
            <th>Alamat Donatur</th>
            <td><?php echo e($data->alamatdonatur); ?></td>
        </tr>

        
        <tr>
            <th>Tanggal Lahir</th>
            <td><?php echo e($data->tanggallahir); ?></td>
        </tr>
        
        <tr>
            <th>Pekerjaan Donatur</th>
            <td><a class="btn btn-primary" href="#"><?php echo e($pekerjaandonatur->namapekerjaandonatur); ?></a></td>
        </tr>
        

        

        <tr>
            <th>Jenis Kelamin</th>
            <td>
                <?php if($data->jeniskelamin == 1): ?>
                    Laki-Laki
                <?php elseif($data->jeniskelamin == 2): ?>
                    Perempuan
                <?php else: ?> 
                    Tidak Disebutkan
                <?php endif; ?>

            </td>
        </tr>
    </tbody>
</table>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-danger btn-lg">HAPUS Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>