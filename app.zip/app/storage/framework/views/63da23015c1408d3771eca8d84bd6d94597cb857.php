<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Semua Transaksi'); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<div style="text-align:center">

        <h1>Laporan Semua Data Transaksi</h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
        
</div>
<!-- //========== TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI===========-->
<!-- //========== JIKA OPSI TRANSAKSI DONASI AKTIF ========== -->
<?php if($istrxdonasi == 1): ?>
    <h2>Transaksi Donasi</h2>
    <table class="table table-striped table-bordered table-condensed">
        <thead class="bg-blue">
            <tr>\
                <th style="text-align:center;width:30px">No.</th>
                <th style="text-align:center;width:75px">Tanggal</th>
                <th style="text-align:center;width:150px">Amil</th>
                <th style="text-align:center;width:150px">Donatur</th>
                <th style="text-align:center;width:300px">Rincian</th>
                <th style="text-align:center;width:150px">Total Donasi</th>
            </tr>
        </thead>

        <tbody>

            <?php 
                $total = 0;
            ?>

            <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:right"><?php echo e(++$key); ?></td>
                    <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                    <td><?php echo e($data->amil->namaamil); ?></td>
                    <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                    
                    <?php
                    $detaildonasi = $data->trxdonasidetail;
                    ?>
                    
                    <td>

                        <?php if(sizeof($detaildonasi) > 0): ?>
                            <table class="table table-condensed" style="margin-bottom:0px">
                            <?php $__currentLoopData = $detaildonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$datadetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td style="width:30px"><?php echo e(++$key); ?></td>
                                    <td style="width:100px"><?php echo e($datadetail->peruntukandonasi->namaperuntukandonasi); ?></td>
                                    <td style="width:100px;text-align:right"><?php echo e(number_format($datadetail->jumlah,0,',','.')); ?></td>
                                </tr>    
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>   
                        <?php endif; ?>
                    </td>

                    <td style="text-align:right">
                        <?php echo e(number_format($data->jumlahtotal,0,',','.')); ?>

                        <br/>
                        <?php if($data->keterangan != null): ?>
                            <small><em>(<?php echo e($data->keterangan); ?>)</em></small>    
                        <?php endif; ?>
                        
                    </td>
                </tr>    
                <?php 
                    $total += $data->jumlahtotal;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-navy">
                    <td></td>
                    <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                    <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                </tr>    

        </tbody>

    </table>
    <br/><hr/>
<?php endif; ?>


<!-- //========== TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ===========-->
<!-- //========== JIKA OPSI TRANSAKSI KOTAK INFAQ AKTIF ========== -->
<?php if($istrxkotakinfaq == 1): ?>
    <h2>Transaksi Kotak Infaq</h2>
    <table class="table table-striped table-bordered table-condensed">
        <thead class="bg-blue">
            <tr>
                <th style="text-align:center;width:30px">No.</th>
                <th style="text-align:center;width:75px">Tanggal</th>
                <th style="text-align:center;width:150px">Amil</th>
                <th style="text-align:center;width:150px">Donatur</th>
                <th style="text-align:center;width:300px">Keterangan</th>
                <th style="text-align:center;width:150px">Total Kotak Infaq</th>
            </tr>
        </thead>

        <tbody>

            <?php 
                $total = 0;
            ?>

            <?php $__currentLoopData = $datakotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:right"><?php echo e(++$key); ?></td>
                    <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                    <td><?php echo e($data->amil->namaamil); ?></td>
                    <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                    <td><em><?php echo e($data->keterangan); ?></em></td>
                    <td style="text-align:right"><?php echo e(number_format($data->jumlahtotal,0,',','.')); ?></td>
                </tr>    
                <?php 
                    $total += $data->jumlahtotal;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-navy">
                    <td></td>
                    <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                    <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                </tr>    

        </tbody>

    </table>
    <br/><hr/>
<?php endif; ?>


<!-- //========== TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU===========-->
<!-- //========== JIKA OPSI TRANSAKSI IBRANKASKU AKTIF ========== -->
<?php if($istrxibrankasku == 1): ?>
    <h2>Transaksi iBrankasku</h2>
    <table class="table table-striped table-bordered table-condensed">
        <thead class="bg-blue">
            <tr>
                <th style="text-align:center;width:30px">No.</th>
                <th style="text-align:center;width:75px">Tanggal</th>
                <th style="text-align:center;width:150px">Amil</th>
                <th style="text-align:center;width:150px">Donatur</th>
                <th style="text-align:center;width:300px">Deskripsi Barang</th>
                <th style="text-align:center;width:150px">Estimasi Valuasi</th>
            </tr>
        </thead>

        <tbody>

            <?php 
                $total = 0;
            ?>

            <?php $__currentLoopData = $dataibrankasku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align:right"><?php echo e(++$key); ?></td>
                    <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                    <td><?php echo e($data->amil->namaamil); ?></td>
                    <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                    <td><em><?php echo e($data->deskripsibarang); ?></em></td>
                    <td style="text-align:right"><?php echo e(number_format($data->nominalvaluasi,0,',','.')); ?></td>
                </tr>    
                <?php 
                    $total += $data->nominalvaluasi;
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="bg-navy">
                    <td></td>
                    <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                    <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                </tr>    

        </tbody>

    </table>

    <br/><hr/>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutblank', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>