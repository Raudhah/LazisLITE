
    <?php if(!empty($message)){ ?>
        <?php if($message['show']): ?>

            <div class="alert alert-<?php echo e($message['type']); ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <?php echo e($message['content']); ?>

            </div>
            
        <?php else: ?>
            <h1>Ooops. ada masalah...</h1> 
        <?php endif; ?>
    
    <?php } ?>


        <?php if($errors->any()): ?>

            <div class="alert alert-error alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>

            </div>
            

        <?php endif; ?>
    
    