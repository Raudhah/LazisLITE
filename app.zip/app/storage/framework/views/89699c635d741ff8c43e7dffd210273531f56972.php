<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Per-Peruntukan Donasi'); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<div style="text-align:center"> 
    <?php if($donatur_id == -1): ?>
        <h1>Laporan Semua Transaksi</h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>
    <?php if($donatur_id != -1): ?>
        <h1>Laporan Data Transaksi Untuk Donatur (<?php echo e(config('app.kodedonatur').$datadonatur->id); ?>) <?php echo e($datadonatur->namadonatur); ?></h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>

        
</div>

        <!-- //========== TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI===========-->
        <!-- //========== JIKA OPSI TRANSAKSI DONASI AKTIF ========== -->
        <?php if(sizeof($datadonasi)>0): ?>
            <h2>Transaksi Donasi dan iBrankasku</h2>

            <!-- //========== LOOPING UNTUK SETIAP TRANSAKSI DONASI ========== -->
           

                <h3><?php echo e(($peruntukandonasi->statusaktif == 1? "":"(TIDAK AKTIF) :: ")); ?><?php echo e($peruntukandonasi->namaperuntukandonasi); ?></h3>

                <table class="table table-striped table-bordered table-condensed">
                    <thead class="bg-blue">
                        <tr>
                            <th style="text-align:center;width:30px">No.</th>
                            <th style="text-align:center;width:75px">Tanggal</th>
                            <th style="text-align:center;width:150px">Amil</th>
                            <th style="text-align:center;width:150px">Donatur</th>
                            <th style="text-align:center;width:300px">Keterangan</th>
                            <th style="text-align:center;width:150px">Total</th>
                        </tr>
                    </thead>
    
    
                    <tbody>
                    
                    <?php 
                        $total = 0;
                    ?>

                <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydonasi=>$donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $donasi->trxdonasidetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td style="text-align:center"><a href="/trxdonasi/<?php echo e($donasi->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxdonasi')); ?>-<?php echo e($donasi->id); ?>)</td>
                                <td style="text-align:center"><?php echo e($donasi->tanggaldonasi); ?></td>
                                <td>(<?php echo e(config('app.kodeamil')); ?><?php echo e($donasi->amil_id); ?>) <?php echo e($donasi->amil->namaamil); ?></td>
                                <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($donasi->donatur_id); ?>) <?php echo e($donasi->donatur->namadonatur); ?></td>
                                <td><?php echo e($donasi->keterangan); ?></td>
                                <td style="text-align:right"><?php echo e(number_format($item->jumlah,0,',','.')); ?></td>
                            </tr>  
                            
                            <?php
                            //hitung totalnya 
                            $total = $total + $item->jumlah;
                            ?>
                            
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                
            
                
                <?php $__currentLoopData = $dataibrankasku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemtrx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      \                            
                            <tr>
                                <td style="text-align:center"><a href="/trxibrankasku/<?php echo e($itemtrx->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxibrankasku')); ?>-<?php echo e($itemtrx->id); ?>)</td>
                                <td style="text-align:center"><?php echo e($itemtrx->tanggaldonasi); ?></td>
                                <td>(<?php echo e(config('app.kodeamil')); ?><?php echo e($itemtrx->amil_id); ?>) <?php echo e($itemtrx->amil->namaamil); ?></td>
                                <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($itemtrx->donatur_id); ?>) <?php echo e($itemtrx->donatur->namadonatur); ?></td>
                                <td><?php echo e($itemtrx->deskripsibarang); ?></td>
                                <td style="text-align:right"><?php echo e(number_format($itemtrx->nominalvaluasi,0,',','.')); ?></td>
                            </tr>  
                            
                            <?php
                            //hitung totalnya 
                            $total = $total + $itemtrx->nominalvaluasi;
                            ?>
                            
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                
                        <tr class="bg-blue">
                            <td></td>
                            <td colspan="4" style="text-align:center"> <strong> TOTAL </strong> </td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                        </tr>  
                
                    </tbody>
                </table>
                <hr/>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutblank', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>