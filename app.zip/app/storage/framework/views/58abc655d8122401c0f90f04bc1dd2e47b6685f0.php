<?php echo $__env->make("master/header1", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <!-- //LAYOUT KERTAS A4 UNTUK DIRECT PRINT DI CSS-->

    <title><?php echo $__env->yieldContent('appname', env('APP_NAME')); ?> | <?php echo $__env->yieldContent('pagename'); ?></title>


  

    <?php echo $__env->make("master/header2a4", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      <!-- Main content -->
      <section class="sheet padding-5mm">

        <?php echo $__env->yieldContent('boxcontent'); ?>

      </section>





<?php echo $__env->make("master/footerblank", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>