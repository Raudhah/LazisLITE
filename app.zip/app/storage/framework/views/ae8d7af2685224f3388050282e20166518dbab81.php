<!-- // pekerjaan donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Edit Konfigurasi'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Konfigurasi'); ?>

<?php $__env->startSection('modulsection', 'Edit'); ?>
<?php $__env->startSection('modulicon', 'fa fa-plus'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Edit Konfigurasi'); ?>

<?php $__env->startSection('boxheader-instruction', 'Isi form berikut. Tanda * wajib diisi. Hanya Konfigurasi yang aktif akan muncul saat Transaksi'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>


<!-- form start -->
<form class="form-horizontal" method="POST" action="/konfigurasi/<?php echo e($data->id); ?>">
<?php echo e(@csrf_field()); ?>

<?php echo e(method_field('PATCH')); ?>


        <!-- //namalaz -->
        <div class="form-group">
            <label for="namalaz" class="col-sm-2 control-label input-lg">
                Nama LAZ *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namalaz" value="<?php echo e(old('namalaz', $data->namalaz)); ?>" id="namalaz" required="required">
            </div>
        </div>
 
        <!-- //kodelaz -->
        <div class="form-group">
            <label for="kodelaz" class="col-sm-2 control-label input-lg">
                Kode LAZ *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="kodelaz" value="<?php echo e(old('kodelaz', $data->kodelaz)); ?>" id="kodelaz" required="required">
            </div>
        </div>
 
        <!-- //namacabang -->
        <div class="form-group">
            <label for="namacabang" class="col-sm-2 control-label input-lg">
                Nama Cabang *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namacabang" value="<?php echo e(old('namacabang', $data->namacabang)); ?>" id="namacabang" required>
            </div>
        </div>
 
        <!-- //kodecabang -->
        <div class="form-group">
            <label for="kodecabang" class="col-sm-2 control-label input-lg">
                Kode Cabang *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="kodecabang" value="<?php echo e(old('kodecabang', $data->kodecabang)); ?>" id="kodecabang" required>
            </div>
        </div>
 
        <!-- //alamatcabang -->
        <div class="form-group">
            <label for="alamatcabang" class="col-sm-2 control-label input-lg">
                Alamat Cabang *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="alamatcabang" value="<?php echo e(old('alamatcabang', $data->alamatcabang)); ?>" id="alamatcabang" required="required">
            </div>
        </div>
 
        <!-- //nomorteleponcabang -->
        <div class="form-group">
            <label for="nomorteleponcabang" class="col-sm-2 control-label input-lg">
                Nomor Telepon*
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="nomorteleponcabang" value="<?php echo e(old('nomorteleponcabang', $data->nomorteleponcabang)); ?>" id="nomorteleponcabang" required="required">
            </div>
        </div>
 
        <!-- //websitecabang -->
        <div class="form-group">
            <label for="websitecabang" class="col-sm-2 control-label input-lg">
                Website LAZ
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="websitecabang" value="<?php echo e(old('websitecabang', $data->websitecabang)); ?>" id="websitecabang">
            </div>
        </div>
 
        <!-- //emailcabang -->
        <div class="form-group">
            <label for="emailcabang" class="col-sm-2 control-label input-lg">
                Email Cabang
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="emailcabang" value="<?php echo e(old('emailcabang', $data->emailcabang)); ?>" id="emailcabang">
            </div>
        </div>

        <!-- //nomorrekeningcabang -->
        <div class="form-group">
            <label for="nomorrekeningcabang" class="col-sm-2 control-label input-lg">
                Nomor Rekening Cabang
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="nomorrekeningcabang" value="<?php echo e(old('nomorrekeningcabang', $data->nomorrekeningcabang)); ?>" id="nomorrekeningcabang">
            </div>
        </div>

        <!-- //keterangan -->
        <div class="form-group">
            <label for="keterangan" class="col-sm-2 control-label input-lg">
                Keterangan
            </label>

            <div class="col-sm-10">
                <textarea rows="4" class="form-control input-lg" name="keterangan" id="keterangan"><?php echo e(old('keterangan', $data->keterangan)); ?></textarea>
            </div>
        </div>

        <!-- //tekskuitansi -->
        <div class="form-group">
            <label for="tekskuitansi" class="col-sm-2 control-label input-lg">
                Teks di Kuitansi
            </label>

            <div class="col-sm-10">
                <textarea rows="4" class="form-control input-lg" name="tekskuitansi" id="tekskuitansi"><?php echo e(old('tekskuitansi', $data->tekskuitansi)); ?></textarea>
            </div>
        </div>
 
        <!-- //namafilelogo -->
        <div class="form-group">
            <label for="namafilelogo" class="col-sm-2 control-label input-lg">
                Nama File Logo *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namafilelogo" value="<?php echo e(old('namafilelogo', $data->namafilelogo)); ?>" id="namafilelogo">
            </div>
        </div>
 
 
        <!-- //namafilettd -->
        <div class="form-group">
            <label for="namafilettd" class="col-sm-2 control-label input-lg">
                Nama File TTD *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namafilettd" value="<?php echo e(old('namafilettd', $data->namafilettd)); ?>" id="namafilettd">
            </div>
        </div>
 
 
        <!-- //namafilebackground -->
        <div class="form-group">
            <label for="namafilebackground" class="col-sm-2 control-label input-lg">
                Nama File Background Kuitansi
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namafilebackground" value="<?php echo e(old('namafilebackground', $data->namafilebackground)); ?>" id="namafilebackground">
            </div>
        </div>
 
 

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Reset</button>
            <button type="submit" class="btn btn-info btn-lg">Update Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>