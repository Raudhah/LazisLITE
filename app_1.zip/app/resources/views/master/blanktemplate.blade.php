<!-- // peruntukan donasi -->

@extends('master.layout')

<!-- //========== SITE TITLE ======== -->
@section('pagename', 'Data Peruntukan Donasi')

<!-- //========== MODUL HEADER ========== -->
@section('modulname', 'Peruntukan Donasi')

@section('modulsection', 'Tampilkan')
@section('modulicon', 'fa fa-inbox')

<!-- //===========BOX  HEADER =========== -->
@section('boxheader-title', 'Tampilkan Peruntukan Donasi')

@section('boxheader-instruction', '...')


<!-- //========== BOX CONTENT =========== -->
@section('boxcontent')




@endsection

<!-- //===========BOX  FOOTER ===========   -->
@section('boxfooter')
        


@endsection

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
@section('footer-code')
    
@endsection
