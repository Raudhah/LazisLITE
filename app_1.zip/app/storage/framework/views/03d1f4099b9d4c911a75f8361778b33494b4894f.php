<!-- // pekerjaan donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Tambah Amil'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Amil'); ?>

<?php $__env->startSection('modulsection', 'Tambah'); ?>
<?php $__env->startSection('modulicon', 'fa fa-plus'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Tambah Amil'); ?>

<?php $__env->startSection('boxheader-instruction', 'Isi form berikut. Tanda * wajib diisi. Hanya Amil yang aktif akan muncul saat Transaksi'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>


<!-- form start -->
<form class="form-horizontal" method="POST" action="<?php echo e(url('')); ?>/amil">
<?php echo e(@csrf_field()); ?>



        <div class="form-group">
            <label for="namaamil" class="col-sm-2 control-label input-lg">
                Nama Amil *
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="namaamil" value="<?php echo e(old('namaamil')); ?>" id="namaamil" placeholder="Nama Amil" required>
            </div>

        </div>

        <div class="form-group">
            <label for="alamatamil" class="col-sm-2 control-label input-lg">
                Alamat Amil
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="alamatamil" value="<?php echo e(old('alamatamil')); ?>" id="alamatamil" placeholder="Jl... No...">
            </div>

        </div>

        <div class="form-group">
            <label for="nomorteleponamil" class="col-sm-2 control-label input-lg">
                Nomor Telepon Amil
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="nomorteleponamil" value="<?php echo e(old('nomorteleponamil')); ?>" id="nomorteleponamil" placeholder="08xxxxx">
            </div>

        </div>

        <div class="form-group">
            <label for="statusaktif" class="col-sm-2 control-label input-lg">
                Status Aktif
            </label>

            <div class="col-sm-10">

                    <label class="input-lg">
                        <input type="radio" name="statusaktif" checked  value="1"> Aktif 
                    </label>
                    <label class="input-lg">
                        <input type="radio" name="statusaktif" value='0'> Non-Aktif
                    </label>
            </div>

        </div>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-info btn-lg">Tambah Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>