<!-- // pekerjaan donatur -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Tambah User'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'User'); ?>

<?php $__env->startSection('modulsection', 'Tambah'); ?>
<?php $__env->startSection('modulicon', 'fa fa-plus'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Tambah User'); ?>

<?php $__env->startSection('boxheader-instruction', 'Isi form berikut. Tanda * wajib diisi. Hanya User yang aktif akan muncul saat Transaksi'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>


<!-- form start -->
<form class="form-horizontal" method="POST" action="<?php echo e(url('')); ?>/user">
<?php echo e(@csrf_field()); ?>



        <div class="form-group">
            <label for="name" class="col-sm-2 control-label input-lg">
                Nama User
            </label>

            <div class="col-sm-10">
                <input type="text" class="form-control input-lg" name="name" value="<?php echo e(old('name')); ?>" id="name" placeholder="Nama User" required>
            </div>

        </div>

        <div class="form-group">
            <label for="email" class="col-sm-2 control-label input-lg">
                Email User* (untuk login)
            </label>

            <div class="col-sm-10">
                <input type="email" class="form-control input-lg" name="email" value="<?php echo e(old('email')); ?>" id="email" placeholder="sesuatu@blabla.com">
            </div>
        </div>

        <div class="form-group">
            <label for="levelakses" class="col-sm-2 control-label input-lg">
                Level Akses
            </label>

            <div class="col-sm-10">
                    <select name="levelakses" id="levelakses"  class="form-control input-lg"  required>
                            <option value="1" <?php echo e((old('levelakses') == 1? "selected":"")); ?>>Admin Harian</option>
                            <option value="2" <?php echo e((old('levelakses') == 2? "selected":"")); ?>>Super Admin</option>
                    </select>
            </div>
        </div>

        <div class="form-group">
                <label for="password" class="col-sm-2 control-label input-lg">
                    Password
                </label>
    
                <div class="col-sm-10">
                    <input type="password" class="form-control input-lg" name="password" value="<?php echo e(old('password')); ?>" id="password" placeholder="Password">
                </div>
        </div>

        <div class="form-group">
                <label for="password_confirmation" class="col-sm-2 control-label input-lg">
                   Konfirmasi Password
                </label>
    
                <div class="col-sm-10">
                    <input type="password" class="form-control input-lg" name="password_confirmation" id="password_confirmation" placeholder="Password Lagi">
                </div>
        </div>

 

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-info btn-lg">Tambah Data</button>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>