<!-- // peruntukan donasi -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Hapus Peruntukan Donasi'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Peruntukan Donasi'); ?>

<?php $__env->startSection('modulsection', 'Hapus'); ?>
<?php $__env->startSection('modulicon', 'fa fa-trash'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Hapus Peruntukan Donasi'); ?>

<?php $__env->startSection('boxheader-instruction', 'Apakah Yakin Anda Mau Menghapus Data Berikut?'); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
<?php $__env->stopSection(); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<!-- form start -->
<form class="form-horizontal" method="POST" action="<?php echo e(url('')); ?>/peruntukandonasi/<?php echo e($data->id); ?>">
<?php echo e(@csrf_field()); ?>

<?php echo e(method_field('DELETE')); ?>


     

        <table class="table table-striped">
            <thead>
                <tr>
                    <th></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <th>Nama Peruntukan Donasi</th>
                    <td><?php echo e($data->namaperuntukandonasi); ?></td>
                </tr>

                <tr>
                    <th>Status</th>
                    <td>
                        <?php if($data->statusaktif): ?>
                            Aktif
                        <?php else: ?>
                            Non-Aktif
                        <?php endif; ?>
    
                    </td>
                </tr>
            </tbody>
        </table>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>
        
        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">

                <?php if(($terpakaitrxdonasi + $terpakaitrxibrankasku) > 0): ?>
                <div class="alert alert-danger alert-dismissable">
                    Maaf Data Tidak bisa dihapus, karena masih terpakai di :
                    <ol> 
                    <?php if($terpakaitrxdonasi > 0): ?>
                        <li><a href="<?php echo e(url('')); ?>/trxdonasi/search" target="_blank">Transaksi Donasi :  <?php echo e($terpakaitrxdonasi); ?> Transaksi</a></li>
                    <?php endif; ?>
                    <?php if($terpakaitrxibrankasku > 0): ?>
                        <li><a href="<?php echo e(url('')); ?>/trxibrankasku/search" target="_blank">Transaksi iBrankasku :  <?php echo e($terpakaitrxibrankasku); ?> Transaksi</a></li>
                    <?php endif; ?>
                    </ol>
                </div>
    
            <?php else: ?> 
                <button type="reset" class="btn btn-default btn-lg">Batal</button>
                <button type="submit" class="btn btn-danger btn-lg">HAPUS Data</button>
            <?php endif; ?>
        </div>
    
    </form>
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>