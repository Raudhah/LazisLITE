<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Per-Peruntukan Donasi'); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<div style="text-align:center"> 
    <?php if($donatur_id == -1): ?>
        <h1>Laporan Semua Transaksi</h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>
    <?php if($donatur_id != -1): ?>
        <h1>Laporan Data Transaksi Untuk Donatur (<?php echo e(config('app.kodedonatur').$datadonatur->id); ?>) <?php echo e($datadonatur->namadonatur); ?></h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>

        
</div>
        <?php 
            $totaltrxdonasi = 0;
            $totaltrxkotakinfaq = 0;
            $totaltrxibrankasku = 0;
            $totalsemua = 0;
        ?>

        <!-- //========== TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI===========-->
        <!-- //========== JIKA OPSI TRANSAKSI DONASI AKTIF ========== -->
        <?php if(sizeof($datadonasi)>0): ?>
            <h2>Transaksi Donasi</h2>

            <!-- //========== LOOPING UNTUK SETIAP TRANSAKSI DONASI ========== -->
           
                <table class="table table-striped table-bordered table-condensed">
                    <thead class="bg-blue">
                        <tr>
                            <th style="text-align:center;width:30px">No.</th>
                            <th style="text-align:center;width:30px">Kuitansi</th>
                            <th style="text-align:center;width:75px">Tanggal</th>
                            <th style="text-align:center;width:150px">Amil</th>
                            <th style="text-align:center;width:150px">Keterangan</th>
                            <th style="text-align:center;width:250px">Detail</th>
                            <th style="text-align:center;width:150px">Total</th>
                        </tr>
                    </thead>
    
    
                    <tbody>
                    
                    

                <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keydonasi=>$donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                        <td style="text-align:center"><?php echo e(++$keydonasi); ?></td>
                        <td style="text-align:center"><a href="<?php echo e(url('')); ?>/trxdonasi/<?php echo e($donasi->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxdonasi')); ?>-<?php echo e($donasi->id); ?>)</td>
                        <td style="text-align:center"><?php echo e($donasi->tanggaldonasi); ?></td>
                        <td>(<?php echo e(config('app.kodeamil')); ?><?php echo e($donasi->amil_id); ?>) <?php echo e($donasi->amil->namaamil); ?></td>
                        <td><?php echo e($donasi->keterangan); ?></td>
                        <!-- //RINCIAN DETAIL DONASINYA-->
                        <td>
                            <table class="table table-condensed" style="margin-bottom:0px">
                            <?php 
                                $total = 0;
                            ?>

                            <?php $__currentLoopData = $donasi->trxdonasidetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                            
                                    <td><?php echo e($item->peruntukandonasi->namaperuntukandonasi); ?></td>
                                    <td style="text-align:right"><?php echo e(number_format($item->jumlah,0,',','.')); ?></td>
                                    <td></td>
                                
                                </tr>
                                <?php
                                //hitung totalnya 
                                $total = $total + $item->jumlah;
                                ?>
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </td>

                        <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>

                        <?php 
                            $totaltrxdonasi += $total;
                        ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

                <tr class="bg-blue">
                        <td></td>
                        <td colspan="5" style="text-align:center"> <strong> TOTAL </strong> </td>
                        <td style="text-align:right"><?php echo e(number_format($totaltrxdonasi,0,',','.')); ?></td>
                </tr>
                
                <?php 
                    $totalsemua += $totaltrxdonasi;
                ?>
            
                </tbody>
            </table>
            <hr/>
                
        <?php endif; ?> 

  
        <!-- //========== TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU===========-->
        <!-- //========== JIKA OPSI TRANSAKSI IBRANKASKU AKTIF ========== -->
        <?php if(sizeof($dataibrankasku)>0): ?>
            <h2>Transaksi iBrankasku</h2>

            <!-- //========== LOOPING UNTUK SETIAP TRANSAKSI IBRANKASKU ========== -->
        
                <table class="table table-striped table-bordered table-condensed">
                    <thead class="bg-blue">
                        <tr>
                            <th style="text-align:center;width:30px">No.</th>
                            <th style="text-align:center;width:30px">Kuitansi.</th>
                            <th style="text-align:center;width:75px">Tanggal</th>
                            <th style="text-align:center;width:150px">Amil</th>
                            <th style="text-align:center;width:150px">Peruntukan Donasi</th>
                            <th style="text-align:center;width:250px">deskripsibarang</th>
                            <th style="text-align:center;width:150px">Nominal Valuasi</th>
                        </tr>
                    </thead>


                    <tbody>
                    
                    
        
                
            <?php $__currentLoopData = $dataibrankasku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor=>$itemtrx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $total=0; ?>
                                                
                        <tr>
                            <td style="text-align:right"><?php echo e(++$nomor); ?></td>
                            <td style="text-align:center"><a href="<?php echo e(url('')); ?>/trxibrankasku/<?php echo e($itemtrx->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxibrankasku')); ?>-<?php echo e($itemtrx->id); ?>)</td>
                            <td style="text-align:center"><?php echo e($itemtrx->tanggaldonasi); ?></td>
                            <td>(<?php echo e(config('app.kodeamil')); ?><?php echo e($itemtrx->amil_id); ?>) <?php echo e($itemtrx->amil->namaamil); ?></td>
                            <td><?php echo e($itemtrx->peruntukandonasi->namaperuntukandonasi); ?></td>
                            <td><?php echo e($itemtrx->deskripsibarang); ?></td>
                            <td style="text-align:right"><?php echo e(number_format($itemtrx->nominalvaluasi,0,',','.')); ?></td>
                        </tr>  
                        
                        <?php
                        //hitung totalnya 
                        $total = $total + $itemtrx->nominalvaluasi;
                        $totaltrxibrankasku += $total;
                        ?>
                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            
                    <tr class="bg-blue">
                        <td></td>
                        <td colspan="5" style="text-align:center"> <strong> TOTAL </strong> </td>
                        <td style="text-align:right"><?php echo e(number_format($totaltrxibrankasku,0,',','.')); ?></td>
                    </tr>  
            
                </tbody>
            </table>
            <hr/>


        <?php endif; ?>

  
        <!-- //========== TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ TRXKOTAKINFAQ===========-->
        <!-- //========== JIKA OPSI TRANSAKSI KOTAKINFAQ AKTIF ========== -->
        <?php if(sizeof($datakotakinfaq)>0): ?>
            <h2>Transaksi Kotak Infaq</h2>

            <!-- //========== LOOPING UNTUK SETIAP TRANSAKSI KOTAKINFAQ ========== -->
        
                <table class="table table-striped table-bordered table-condensed">
                    <thead class="bg-blue">
                        <tr>
                            <th style="text-align:center;width:30px">No.</th>
                            <th style="text-align:center;width:30px">Kuitansi.</th>
                            <th style="text-align:center;width:75px">Tanggal</th>
                            <th style="text-align:center;width:150px">Amil</th>
                            <th style="text-align:center;width:250px">keterangan</th>
                            <th style="text-align:center;width:150px">Nominal Valuasi</th>
                        </tr>
                    </thead>


                    <tbody>
                    
                    
        
                
            <?php $__currentLoopData = $datakotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nomor=>$itemtrx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php $total=0; ?>
                                                
                        <tr>
                            <td style="text-align:right"><?php echo e(++$nomor); ?></td>
                            <td style="text-align:center"><a href="<?php echo e(url('')); ?>/trxkotakinfaq/<?php echo e($itemtrx->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxkotakinfaq')); ?>-<?php echo e($itemtrx->id); ?>)</td>
                            <td style="text-align:center"><?php echo e($itemtrx->tanggaldonasi); ?></td>
                            <td>(<?php echo e(config('app.kodeamil')); ?><?php echo e($itemtrx->amil_id); ?>) <?php echo e($itemtrx->amil->namaamil); ?></td>
                            <td><?php echo e($itemtrx->keterangan); ?></td>
                            <td style="text-align:right"><?php echo e(number_format($itemtrx->jumlahtotal,0,',','.')); ?></td>
                        </tr>  
                        
                        <?php
                        //hitung totalnya 
                        $total = $total + $itemtrx->jumlahtotal;
                        $totaltrxkotakinfaq += $total;
                        ?>
                        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            
                    <tr class="bg-blue">
                        <td></td>
                        <td colspan="4" style="text-align:center"> <strong> TOTAL </strong> </td>
                        <td style="text-align:right"><?php echo e(number_format($totaltrxkotakinfaq,0,',','.')); ?></td>
                    </tr>  
            
                </tbody>
            </table>
            <hr/>


        <?php endif; ?>


        <h2>Rekapitulasi</h2>

            <!-- //========== LOOPING UNTUK SETIAP TRANSAKSI KOTAKINFAQ ========== -->
        
                <table class="table table-striped table-bordered table-condensed" style="width:350px">
                    <thead class="bg-blue">
                        <tr>
                            <th style="text-align:center;width:30px">No.</th>
                            <th style="text-align:center;width:150px">Keterangan</th>
                            <th style="text-align:center;width:150px">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $nomor = 0; ?>
                        <?php if(sizeof($datadonasi)>0): ?>
                            <tr>
                                <td><?php echo e(++$nomor); ?></td>
                                <td>Transaksi Donasi</td>
                                <td style="text-align:right"><?php echo e(number_format($totaltrxdonasi,0,',','.')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if(sizeof($dataibrankasku)>0): ?>
                            <tr>
                                <td><?php echo e(++$nomor); ?></td>
                                <td>Transaksi iBrankasku</td>
                                <td style="text-align:right"><?php echo e(number_format($totaltrxibrankasku,0,',','.')); ?></td>
                            </tr>
                        <?php endif; ?>
                        <?php if(sizeof($datakotakinfaq)>0): ?>
                            <tr>
                                <td><?php echo e(++$nomor); ?></td>
                                <td>Transaksi Kotak Infaq</td>
                                <td style="text-align:right"><?php echo e(number_format($totaltrxkotakinfaq,0,',','.')); ?></td>
                            </tr>
                        <?php endif; ?>

                        <?php 
                            $totalsemua = $totaltrxdonasi + $totaltrxibrankasku + $totaltrxkotakinfaq;
                        ?>

                        <tr class="bg-blue">
                            <td colspan="2" style="text-align:center"><strong>TOTAL SEMUA</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($totalsemua,0,',','.')); ?></td>
                        </tr>
                    </tbody>
                </table>


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutblank', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>