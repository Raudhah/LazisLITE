<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Rekap Per Donatur'); ?>

<?php $__env->startSection('headertag'); ?>
    <meta name="_token" content="<?php echo e(csrf_token()); ?>" />
    
<?php $__env->stopSection(); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Laporan Rekap Per Donatur'); ?>

<?php $__env->startSection('modulsection', 'Laporan'); ?>
<?php $__env->startSection('modulicon', 'fa fa-bar-chart'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title', 'Laporan Per Donatur'); ?>

<?php $__env->startSection('boxheader-instruction', 'Pilih laporan yang ingin Anda tampilkan.'); ?>


<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

    <!--//ambil dari file untuk formatnya   -->
    <?php echo $__env->make('master/general/boxmessage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>



<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>


<p>Laporan ini akan menampilkan Data dari Donatur </p>

<!-- form start -->
<form class="form-horizontal" method="POST" action="<?php echo e(url('')); ?>/laporan/donatur">
<?php echo e(@csrf_field()); ?>

    
<!-- // DONATURNYA -->
<div class="form-group">
    <label for="namatrxdonasi" class="col-sm-2 control-label input-lg">
        Donatur
    </label>

    <div class="col-sm-10">
        <div id="tombolpilihan">
            <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#modal-donatur-cari">
                <i class="fa fa-search"></i> Cari Donatur
            </button>

            atau 

            <button type="button" class="btn btn-success btn-lg" id="tombolcaridisemuadonatur">
                <i class="fa fa-plus"></i> Cari di SEMUA DONATUR
            </button>
        </div>

        <!-- //ini nanti akan hidden dan muncul jika sudah OK -->
        <div class="row" id="datapilihan">
            <div class="col-sm-12">
                <!-- //INI UNTUK KEPERLUAN FORM NYA -->
                <input type="hidden" name="donatur_id" id="donatur_id" value="0">

                <!-- //Menampilkan donatur yang dipilih -->
                <table class="table table-striped">
                    <tr>
                        <th>Nama</th>
                        <td id="detailnamadonatur">N/A</td>
                    </tr>
                    <tr>
                        <th>Alamat</th>
                        <td id="detailalamatdonatur">N/A</td>
                    </tr>
                    <tr>
                        <th>Nomor Telepon</th>
                        <td id="detailnomortelepondonatur">N/A</td>
                    </tr>
                    <tr>
                        <th></th>
                        <td>
                            <span id="tomboldetaildonatur">
                                
                            </span>

                            <button type="button" class="btn btn-warning btn-xs" data-toggle="modal" data-target="#modal-donatur-cari">
                                    Ubah Donatur
                            </button>
                        </td>
                    </tr>
                </table>

            </div>
        </div>
        <!-- //  /datapilihan -->

        <!-- //CARI DI SEMUA DONATURini nanti akan hidden dan muncul jika sudah OK -->
        <div class="row" id="semuadonatur">
            <div class="col-sm-12">
                <!-- //INI UNTUK KEPERLUAN FORM NYA -->
                <input type="checkbox" name="checkboxsemuadonatur" id="checkboxsemuadonatur" value="1"> Cari di SEMUA DONATUR
                <input type="hidden" name="checkboxsemuadonatur" value="1">
                <br/>
            </div>
        </div>
        <!-- //  /semuadonatur -->

    </div>

    <!-- //  /col-sm-10 -->


</div>
<!-- //  /form-group -->


        <!-- //JENIS LAPORAN -->
        <div class="form-group" id="top100">

            <label for="tipelaporan" class="col-sm-2 control-label input-lg">
                Tipe Laporan
            </label>
            
            <div class="col-sm-10">
                <div class="row input-lg">
                    <div class="col-sm-12">
                        <input type="radio" name="tipelaporan" id="tipelaporansemua" value="1" checked>100 donatur Jumlah Terbanyak
                    </div>
                    <div class="col-sm-12">
                        <input type="radio" name="tipelaporan" id="tipelaporansemua" value="2">100 donatur Yang Paling Sering
                    </div>
                </div>
            </div>
        </div>


        <!-- //PERIODE LAPORAN -->
        <div class="form-group">
            <label for="periodelaporan" class="col-sm-2 control-label input-lg">
                Periode Laporan
            </label>

            <div class="col-sm-10">
                <div class="input-group date">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <input required="required" type="text"  name="periodelaporan" id="periodelaporan" value="<?php echo e(old('periodelaporan')); ?>"  class="form-control pull-right">
                </div>
                <!-- //.input group date -->    
            </div>

        </div>


        <!-- //RADIO URUTKAN BERDASARKAN -->
        <div class="form-group" id="urutkanberdasarkan">

            <label for="sortby" class="col-sm-2 control-label input-lg">
                Urutkan Berdasarkan
            </label>
            
            <div class="col-sm-10">
                <label class="input-lg">
                    <input type="radio" name="sortby" value="1" checked> Tanggal (Terbaru)
                </label>
                <label class="input-lg">
                    <input type="radio" name="sortby" value="2"> Tanggal (Terlama)
                </label>
            </div>
        </div>

<?php $__env->stopSection(); ?>

<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>

<!--// ================================================= -->
<!--// MODAL CARI DONATUR -->
<div class="modal modal-primary fade" id="modal-donatur-cari">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Cari Dari Data Donatur yang sudah Ada</h4>
            </div>

            <div class="modal-body">
                <p>Masukkan bagian dari nama / alamat / nomor telepon &hellip;</p>
                    
                    <div class="col-sm-12 form-group">
                        
                            <input type="text" class="form-control input-lg" id="inputcaridonatur" placeholder="Nama / Alamat / No. Telp.">

                            <button type="button"  onclick="caridonatur()" class="btn btn-default btn-lg"><i class="fa fa-search"></i>CARI</button>

                    </div>


                    <div class="col-sm-12 form-group">
                        
                        <div id="hasilpencarian">

                        </div>
                    </div>
                        
            </div>

            <div class="modal-footer">
                <div class="col-sm-10 form-group">
                        <button type="button" class="btn btn-outline pull-left" data-dismiss="modal">Tutup</button>    
                </div>
                
            </div>
        </div>
        <!-- /.modal-content -->
    </div>
    <!-- /.modal-dialog -->
</div>
<!-- /.modal MODAL CARI DONATUR-->


        <div class="col-sm-2">
        </div>

        <div class="col-sm-10">
            <button type="reset" class="btn btn-default btn-lg">Batal</button>
            <button type="submit" class="btn btn-info btn-lg">Tampilkan Laporan</button>
        </div>
    
    </form> 
    <!-- /form -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    <script>


        //inisialisasi dulu
        $('#datapilihan').hide();
        $('#semuadonatur').hide();
        $('#top100').hide();
        //$('#urutkanberdasarkan').hide();
        

        $('#tombolcaridisemuadonatur').click(function(){
            $('#semuadonatur').show(500);
            $('#top100').show(500);
            $('#tombolpilihan').hide(500);
            $('#donatur_id').val(-1);
            $('#checkboxsemuadonatur').prop("checked", true);
        });


        //jika dalam teks pencarian, ENTER di tekan, apa yang terjadi.. 
        $("#inputcaridonatur").keypress(function(event) {
            if (event.which == 13) {
                event.preventDefault();
                caridonatur();
            }
        });


        function caridonatur(){
            //setup ajax
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                }
            });

            //mendapatkan string/text query pencariannya 
            var inputcaridonatur = $("#inputcaridonatur").val();

            $.ajax({

                type:'POST',
     
                url:'<?php echo e(url('')); ?>/donatur/ajaxsearch',
     
                data:{function:'searchdonatur', query: inputcaridonatur},
     
                success:function(data){
                   //alert('berhasil dapatnya');

                   //success ajaxnya kah?
                   console.log(data.success);
                   if(data.ketemu == 1){
                        console.log('Alhamdulillah data ditemukan');
                        console.log(data.data);
                        //tampilkan hasil pencarian ke user
                        displaySearchResult(data.data);
                   }
                   else{
                        $("#hasilpencarian").html('<span class="alert alert-danger">Maaf, data dengan kata <em><strong> \"' + inputcaridonatur+" \"</strong></em>yang dicari tidak ada...</span>");
                        console.log('Maaf tidak ditemukan data tersebut');
                   }
                   
                   
                },
                error:function(error){
                    console.log(error);
                    //alert('Error 701 : gagal mendapatkan data pencarian donatur dari server');
                }
     
             });
        }

        //menampilkan data hasil pencarian apabila sukses ditemukan sesuai dengan query
        function displaySearchResult(data){
            //alert("bersiap menampilkan datanya");
            //kosongkan dulu isinya
            $("#hasilpencarian").html(""); 
            var tekshasilpencarian = "";
            tekshasilpencarian += '<table class="table">';
            tekshasilpencarian += "<thead>";
            tekshasilpencarian += "<tr>";
            tekshasilpencarian += "<td>Nama</td><td>Alamat</td><td>No.Telepon</td><td></td>";
            tekshasilpencarian += "</tr>";
            tekshasilpencarian += "</thead>";
            tekshasilpencarian += "<tbody>";
            for(var i=0; i < data.length; i++){

                tekshasilpencarian += "<tr>";
                tekshasilpencarian += '<td><span id="nama'+data[i].id+'">' + data[i].namadonatur + "</span></td>";
                if(data[i].alamatdonatur != null){
                    tekshasilpencarian += "<td>" + data[i].alamatdonatur + "</td>";
                }
                else{
                    tekshasilpencarian += "<td>" + 'N/A' + "</td>";
                }
                
                if(data[i].nomortelepondonatur != null){
                    tekshasilpencarian += "<td>" + data[i].nomortelepondonatur + "</td>";
                }
                else{
                    tekshasilpencarian += "<td>" + 'N/A' + "</td>";
                }         

                tekshasilpencarian += '<td><a class="btn btn-success" data-dismiss="modal" aria-label="Close"';
                tekshasilpencarian += ' onclick="pilihdonatur('+ data[i].id+')">';
                tekshasilpencarian += 'Pilih</a></td>';     

                tekshasilpencarian += "</tr>";
            }
            tekshasilpencarian += "</tbody>";
            tekshasilpencarian += "</table>";

            var inidatanya = "Ini data hasil pencariannya : " + data;

            $("#hasilpencarian").html(tekshasilpencarian); 

            GLOBALDATA = data;

        }

        function pilihdonatur(iddonatur){
            //alert("Sebenarnya ini tu dipanggila apa ndak ya?");
            console.log("Donatur terpilih " + iddonatur);
            console.log("isi GLOBALDATA ");
            console.log(GLOBALDATA);
            
            var data = GLOBALDATA;

            for(var i=0; i < data.length; i++){
                if(data[i].id == iddonatur){
                    //tampilkan di formnya yuk disini
                    console.log("DETAIL DONATUR TERPILIH : ");
                    console.log("NAMA  " + data[i].namadonatur );
                    console.log("ALAMAT  " + data[i].alamatdonatur );
                    console.log("NOMOR TELEPON  " + data[i].nomortelepondonatur );
                    console.log("AMIL  " + data[i].amil_id );

                    //menampilkan datanya
                    $("#datapilihan").show(500);

                    $("#detailnamadonatur").html(data[i].namadonatur);
                    $("#detailalamatdonatur").html(data[i].alamatdonatur);
                    $("#detailnomortelepondonatur").html(data[i].nomortelepondonatur);
                    
                    //ini isi form hidden
                    $("#donatur_id").val(data[i].id);


                    //set amil pada nilainya
                    $("#amil_id").val(data[i].amil_id);
                    
                    //membuat tombol klik untuk detail donatur, buka di window baru
                    var tekslinkdetail = '<a href="<?php echo e(url('')); ?>/donatur/' + data[i].id+ '" target="_blank" class="btn btn-primary btn-xs"> Detail Donatur </a>'
                    $("#tomboldetaildonatur").html(tekslinkdetail);

                    //mari memilih petugas Amil yang sesuai dengan ini

                    //menyembunyikan tombol
                    $("#tombolpilihan").hide(500);
                    $('#semuadonatur').hide();

                }
            }
        }



        //Date picker
        $('#periodelaporan').daterangepicker({
            
            format : "dd/mm/yyyy",
            locale: {
                format: 'DD/MM/YYYY' // --------Here
            },
            autoclose: true,
            allowEmpty:true,
        })

        $('#periodelaporan').val('');


    </script>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>