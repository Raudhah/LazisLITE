<!-- // dashboard -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Data Dashboard'); ?>

<!-- //========== MODUL HEADER ========== -->
<?php $__env->startSection('modulname', 'Dashboard'); ?>

<?php $__env->startSection('modulsection', 'Tampilkan'); ?>
<?php $__env->startSection('modulicon', 'fa fa-list'); ?>

<!-- //===========BOX  HEADER =========== -->
<?php $__env->startSection('boxheader-title'); ?>

    Assalammualaikum <?php echo e(Auth::user()->name); ?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('boxheader-instruction'); ?>
<?php
        echo "Semoga Berkah pada Hari Ini :"; 
        $today = date("d/m/Y"); 
        echo $today;  
    ?>
<?php $__env->stopSection(); ?>

<!-- //===========BOX MESSAGE, for ANY ALERT AVAILABLE =========== -->
<?php $__env->startSection('boxmessage'); ?>

<?php $__env->stopSection(); ?>

<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

    <div class="row">
    

        <?php $__currentLoopData = $smallboxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $smallbox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            


            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box <?php echo e($smallbox["bg"]); ?>">
                <div class="inner">
                    <h3><?php echo e(number_format($smallbox["number"],0,',','.')); ?></h3>

                    <p><?php echo e($smallbox["text"]); ?></p>
                </div>
                <div class="icon">
                    <i class="fa <?php echo e($smallbox["icon"]); ?>"></i>
                </div>
                <a href="<?php echo e(url('')); ?>/<?php echo e($smallbox["url"]); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>  
    <!-- end div row -->



    <div class="row">
        <div class="col-md-12">
            <div class="box box-primary">
                <div class="box-header with-border">
                  
                  <h3 class="box-title">Grafik Perolehan Tahun Ini</h3>
      
                    <div class="box-tools pull-right">
                      <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                </div>
                <!-- /.box-header -->
                <div class="box-body">
                  <div class="chart">
                      <canvas id="barChart" style="height:400px; width:500px; border:1px solid black"></canvas>
                  </div>

                </div>
                
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-md-6">
                <!-- PRODUCT LIST -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">10 Donatur Rutin Terbaru</h3>
      
                    <div class="box-tools pull-right">
                      <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                  </div>
                  <!-- /.box-header -->
                  <div class="box-body">
                    <ul class="products-list product-list-in-box">

                        <?php $__currentLoopData = $listdonaturrutinterbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        

                      <li class="item">
                        <div class="product-info">
                            
                          <a href="<?php echo e(url('')); ?>/donatur/<?php echo e($donatur->id); ?>" class="product-title">
                            <?php echo e(++$key); ?>.
                            <?php echo e($donatur->namadonatur); ?>

                            <span class="label label-warning pull-right">Detail</span></a>
                          <span class="product-description">
                                
                              </span>
                        </div>
                      </li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <!-- /.item -->
                    </ul>
                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer text-center">
                    <a href="<?php echo e(url('')); ?>/donatur" class="uppercase">Lihat Seluruhnya</a>
                  </div>
                  <!-- /.box-footer -->
                </div>
                <!-- /.box -->


        </div>

        <div class="col-md-6">
                <!-- PRODUCT LIST -->
                <div class="box box-primary">
                  <div class="box-header with-border">
                    <h3 class="box-title">10 Kotak Infaq Terbaru</h3>
      
                    <div class="box-tools pull-right">
                      <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                    </div>
                  </div>
                  <!-- /.box-header -->
                  <div class="box-body">
                    <ul class="products-list product-list-in-box">

                        <?php $__currentLoopData = $listkotakinfaqterbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        

                      <li class="item">
                        <div class="product-info">
                            
                          <a href="<?php echo e(url('')); ?>/<?php echo e($donatur->id); ?>" class="product-title">
                            <?php echo e(++$key); ?>.
                            <?php echo e($donatur->namadonatur); ?>

                            <span class="label label-warning pull-right">Detail</span></a>
                          <span class="product-description">
                                
                              </span>
                        </div>
                      </li>

                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      <!-- /.item -->
                    </ul>
                  </div>
                  <!-- /.box-body -->
                  <div class="box-footer text-center">
                    <a href="<?php echo e(url('')); ?>/donatur" class="uppercase">Lihat Seluruhnya</a>
                  </div>
                  <!-- /.box-footer -->
                </div>
                <!-- /.box -->


        </div>


    </div>

<?php $__env->stopSection(); ?>



<!-- //===========BOX  FOOTER ===========   -->
<?php $__env->startSection('boxfooter'); ?>

<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.3/Chart.bundle.js"></script>

<script>
  
    $(document).ready(function(){

      var barChartData = {
        labels  : ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'],
        datasets: [
          {
            label               : 'Donasi',
            backgroundColor     : 'rgba(250, 197, 5, 1)',
            borderColor         : 'rgba(231, 186, 24, 1)',
            data                : [
              <?php $__currentLoopData = $barchart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($item->trxdonasi); ?>, 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              ]
          },
          {
            label               : 'Kotak Infaq',
            backgroundColor     : 'rgba(60,141,188,0.9)',
            borderColor         : 'rgba(60,141,188,0.8)',
            data                : [
              <?php $__currentLoopData = $barchart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($item->trxkotakinfaq); ?>, 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
          },
          {
            label               : 'iBrankasku',
            backgroundColor     : 'rgba(179, 232, 33, 1)',
            borderColor         : 'rgba(123, 162, 17, 1)',
            data                : [
              <?php $__currentLoopData = $barchart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($item->trxibrankasku); ?>, 
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
          }

        ]
      }
  
      
     
    var ctx = document.getElementById("barChart").getContext('2d');
    var myChart = new Chart(ctx, {
        type: 'bar',
        data: barChartData,
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero:true
                    }
                }]
            }
        }
    });
    });




</script>


    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>