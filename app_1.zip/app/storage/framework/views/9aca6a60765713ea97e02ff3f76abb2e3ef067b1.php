<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Semua Transaksi'); ?>



<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>
    <div class="kuitansi" style="min-height: 75mm;border: 1px solid green;margin-bottom: 2mm;line-height: 16px;background:url('<?php echo e(asset('storage/'.$konfig->namafilebackground)); ?>') no-repeat top center fixed;background-size:cover;">
            <div class="row" style="">
                <!-- //BAGIAN KIRI -->
                <div class="col-sm-8">
                    <!-- //BARIS KOP /HEADER KUITANSI -->
                    <div class="row">
                            <div class="col-sm-3" style="text-align:right">
                                    <img src="<?php echo e(asset('storage/'.$konfig->namafilelogo)); ?>" style="height:22mm"/>
                            </div>
                            <div class="col-sm-9" style="text-align:center;">
                                    <strong><?php echo e($konfig->namalaz); ?> <?php echo e($konfig->namacabang); ?></strong>
                                    <br/>

                                    <small> 
                                        <?php
                                        echo nl2br($konfig->keterangan);
                                        ?>
                                        <br/><em><?php echo e($konfig->alamatcabang); ?></em>
                                    </small>
                            </div>
                    </div>

                    <!-- //HALAMAN UTAMA DETAIL KUITANSI ADA DISINI -->
                    <div class="row">
                        <div class="col-sm-12" style="text-align:center">
                            <h4 style="margin:0px"><strong>Tanda Terima Pembayaran</strong></h4>

                            <table class="table table-striped table-condensed" style="margin-left:2mm;margin-bottom:0px;font-size: 14px">
                                    <thead>
                                        <tr class="bg-primary">
                                            <th style="padding:0px;width:10mm;text-align:center">No.</th>
                                            <th style="padding:0px;width:80mm;text-align:center">Peruntukan Donasi</th>
                                            <th style="padding:0px;width:30mm;text-align:center">Jumlah</th>
                                        </tr>
                                    </thead>
                                
                                    <tbody>
                                        <!- // PERINCIANNYA-->
                                        <?php $__currentLoopData = $listtrxdonasidetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$trxdonasidetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <tr>
                                                <td style="padding:0px;text-align:center"><?php echo e(++$key); ?></td>
                                                <td style="padding:0px;text-align:left"><?php echo e($trxdonasidetail->peruntukandonasi->namaperuntukandonasi); ?></td>
                                                <td style="padding:0px;text-align:right"><?php echo e(number_format($trxdonasidetail->jumlah,0,',','.')); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        <!- // JUMLAH TOTALNYA-->
                                            <tr style="" class="bg-gray">
                                                <td style="padding:0px;" class=""></td>
                                                <td style="padding:0px;" class=""><strong> JUMLAH TOTAL</strong></td>
                                                <td style="padding:0px;text-align:right"><strong><?php echo e(number_format($jumlahtotal,0,',','.')); ?></strong></td>
                                            </tr>
                                            
                                    </tbody>
                            </table>
                            <div style="line-height:14px; font-size:12px; font-style:italic"><?php echo e($konfig->tekskuitansi); ?></div>
                        </div>
                    </div>

                </div>

                <!-- //BAGIAN KANAN -->
                <div class="col-sm-4">
                        <table style="border:0px solid black">
                            <tr>
                                <td><strong>Nomor</strong></td>
                                <td>: <?php echo e(config('app.kodekuitansi.trxdonasi')); ?><?php echo e($idtransaksi); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Tanggal</strong></td>
                                <td>: <?php echo e($tanggaldonasi); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Amil</strong></td>
                                <td>: (<?php echo e(config('app.kodeamil')); ?><?php echo e($dataamil->id); ?>) <?php echo e($dataamil->namaamil); ?></td>
                            </tr>
                            <tr>
                                <td><strong>Jenis</strong></td>
                                <td>: Donasi</td>
                            </tr>
                            <tr>
                                <td style="vertical-align:text-top"><strong>Donatur </strong></td>
                                <td>
                                    <div style="min-height:23mm;background-color:inherit">
                                            : <?php echo e($datadonatur->namadonatur); ?> (<?php echo e(config('app.kodedonatur')); ?><?php echo e($datadonatur->id); ?>), <?php echo e($datadonatur->alamatdonatur); ?>, <?php echo e($datadonatur->nomortelepondonatur); ?>,
                                    </div>
                                </td>
                            </tr>
                        </table>

                        <div class="row" style="height:30mm">
                            <div class="col-sm-12" style="text-align:center">
                                <img src="<?php echo e(asset('storage/'.$konfig->namafilettd)); ?>" style="max-width:45mm; max-height:25mm"/>
                        
                            </div>
                        </div>
                </div>
            </div>
            <!-- //END BAGIAN KANAN-->

            <div>
                <div style="text-align:center; font-size:12px; font-weight:bold; font-style:italic; background-color:orange; overflow:hidden">
                    <?php echo e($konfig->nomorrekeningcabang); ?> 
                    <br/> Telepon : <?php echo e($konfig->nomorteleponcabang); ?> 
                    <?php echo e(($konfig->emailcabang==null? "": "Email : ".$konfig->emailcabang)); ?> 
                    <?php echo e(($konfig->websitecabang==null? "": "Website : ".$konfig->websitecabang)); ?> 
                </div>
            </div>


    </div>
 
<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layouta4', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>