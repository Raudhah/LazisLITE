<!-- // pekerjaan laporan -->



<!-- //========== SITE TITLE ======== -->
<?php $__env->startSection('pagename', 'Laporan Per-Amil'); ?>


<!-- //========== BOX CONTENT =========== -->
<?php $__env->startSection('boxcontent'); ?>

<div style="text-align:center">

    <?php if($tipelaporan == 1): ?>
        <h1>Laporan Semua Data Transaksi Amil</h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>
    <?php if($tipelaporan == 2): ?>
        <h1>Laporan Tanggungan Donatur Yang Sudah Terambil</h1>
        <h4>Periode Laporan : <?php echo e($periodelaporan); ?></h4>
    <?php endif; ?>
    <?php if($tipelaporan == 3): ?>
        <h1>Rekap Laporan Tanggungan Donatur dari Amil</h1>
    <?php endif; ?>
    <?php if($tipelaporan == 4): ?>
        <h1>Daftar Donatur Yang Menjadi Tanggungan</h1>
    <?php endif; ?>
        <h4>Amil : <?php echo e($dataamil->namaamil); ?> (<?php echo e(config('app.kodeamil').$dataamil->id); ?>)</h4>
        
</div>


<!-- //========== JIKA DIMINTA MENAMPILKAN LAPORAN SEMUA DATA TRANSAKSINYA ========== -->
<?php if($tipelaporan==1): ?>
        <!-- //========== TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI TRXDONASI===========-->
        <!-- //========== JIKA OPSI TRANSAKSI DONASI AKTIF ========== -->
        <?php if($istrxdonasi == 1 && sizeof($datadonasi)>0): ?>
            <h2>Transaksi Donasi</h2>
            <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">Tanggal</th>
                        <th style="text-align:center;width:150px">Amil</th>
                        <th style="text-align:center;width:150px">Donatur</th>
                        <th style="text-align:center;width:300px">Rincian</th>
                        <th style="text-align:center;width:150px">Total Donasi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                        $total = 0;
                    ?>

                    <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:right"><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                            <td><?php echo e($data->amil->namaamil); ?></td>
                            <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                            
                            <?php
                            $detaildonasi = $data->trxdonasidetail;
                            ?>
                            
                            <td>

                                <?php if(sizeof($detaildonasi) > 0): ?>
                                    <table class="table table-condensed" style="margin-bottom:0px">
                                    <?php $__currentLoopData = $detaildonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$datadetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="width:30px"><?php echo e(++$key); ?></td>
                                            <td style="width:100px"><?php echo e($datadetail->peruntukandonasi->namaperuntukandonasi); ?></td>
                                            <td style="width:100px;text-align:right"><?php echo e(number_format($datadetail->jumlah,0,',','.')); ?></td>
                                        </tr>    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>   
                                <?php endif; ?>
                            </td>

                            <td style="text-align:right">
                                <?php echo e(number_format($data->jumlahtotal,0,',','.')); ?>

                                <br/>
                                <?php if($data->keterangan != null): ?>
                                    <small><em>(<?php echo e($data->keterangan); ?>)</em></small>    
                                <?php endif; ?>
                                
                            </td>
                        </tr>    
                        <?php 
                            $total += $data->jumlahtotal;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-navy">
                            <td></td>
                            <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                        </tr>    

                </tbody>

            </table>
            <br/><hr/>
        <?php endif; ?>


        <!-- //========== TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ TRXKOTAK INFAQ===========-->
        <!-- //========== JIKA OPSI TRANSAKSI KOTAK INFAQ AKTIF ========== -->
        <?php if($istrxkotakinfaq == 1  && sizeof($datakotakinfaq)>0): ?>
            <h2>Transaksi Kotak Infaq</h2>
            <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">Tanggal</th>
                        <th style="text-align:center;width:150px">Amil</th>
                        <th style="text-align:center;width:150px">Donatur</th>
                        <th style="text-align:center;width:300px">Keterangan</th>
                        <th style="text-align:center;width:150px">Total Kotak Infaq</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                        $total = 0;
                    ?>

                    <?php $__currentLoopData = $datakotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:right"><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                            <td><?php echo e($data->amil->namaamil); ?></td>
                            <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                            <td><em><?php echo e($data->keterangan); ?></em></td>
                            <td style="text-align:right"><?php echo e(number_format($data->jumlahtotal,0,',','.')); ?></td>
                        </tr>    
                        <?php 
                            $total += $data->jumlahtotal;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-navy">
                            <td></td>
                            <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                        </tr>    

                </tbody>

            </table>
            <br/><hr/>
        <?php endif; ?>


        <!-- //========== TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU TRXIBRANKASKU===========-->
        <!-- //========== JIKA OPSI TRANSAKSI IBRANKASKU AKTIF ========== -->
        <?php if($istrxibrankasku == 1 && sizeof($dataibrankasku)>0): ?>
            <h2>Transaksi iBrankasku</h2>
            <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">Tanggal</th>
                        <th style="text-align:center;width:150px">Amil</th>
                        <th style="text-align:center;width:150px">Donatur</th>
                        <th style="text-align:center;width:300px">Deskripsi Barang</th>
                        <th style="text-align:center;width:150px">Estimasi Valuasi</th>
                    </tr>
                </thead>

                <tbody>

                    <?php 
                        $total = 0;
                    ?>

                    <?php $__currentLoopData = $dataibrankasku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:right"><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e($data->tanggaldonasi); ?></td>
                            <td><?php echo e($data->amil->namaamil); ?></td>
                            <td>(<?php echo e(config('app.kodedonatur')); ?><?php echo e($data->donatur_id); ?>) <?php echo e($data->donatur->namadonatur); ?></td>
                            <td><em><?php echo e($data->deskripsibarang); ?></em></td>
                            <td style="text-align:right"><?php echo e(number_format($data->nominalvaluasi,0,',','.')); ?></td>
                        </tr>    
                        <?php 
                            $total += $data->nominalvaluasi;
                        ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="bg-navy">
                            <td></td>
                            <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                        </tr>    

                </tbody>

            </table>

            <br/><hr/>
        <?php endif; ?>    

<?php endif; ?>
<!-- //========== ENDIF TIPELAPORAN == 1 ========== -->


<!-- //========== JIKA TIPELAPORAN == 3 ========== -->
<!-- // TIPE LAPORAN YANG SUDAH TERAMBIL (DARI TANGGUNGAN AMIL)-->

<?php if($tipelaporan==2): ?>
    <!--//tampilkan daftar donaturnya dulu  ->

    <!-- // === TAMPILKAN DATA DONATUR RUTIN YANG MENJADI TANGGUNGANNYA==============   -->
    <?php if(sizeof($datadonatur)>0): ?>
        
        <h3>Data Donatur Rutin</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:30px">Kuitansi</th>
                        <th style="text-align:center;width:70px">Tanggal</th>
                        <th style="text-align:center;width:100px">Donatur</th>
                        <th style="text-align:center;width:100px">Amil Yang Mengambil</th>
                        <th style="text-align:center;width:100px">Rincian</th>
                        <th style="text-align:center;width:150px">Total</th>
                    </tr>
                </thead>

                        <?php 
                            $total = 0;
                        ?>

                <tbody>
                    <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e(config('app.kodekuitansi.trxdonasi').$donasi->id); ?></td>
                            <td><?php echo e($donasi->tanggaldonasi); ?></td>
                            <td>(<?php echo e(config('app.kodedonatur').$donasi->donatur->id); ?>) <?php echo e($donasi->donatur->namadonatur); ?></td>
                            <td>(<?php echo e(config('app.kodeamil').$donasi->amil->id); ?>) <?php echo e($donasi->amil->namaamil); ?></td>
                            <?php
                            $detaildonasi = $donasi->trxdonasidetail;
                            ?>
                            
                            <td>

                                <?php if(sizeof($detaildonasi) > 0): ?>
                                    <table class="table table-condensed" style="margin-bottom:0px">
                                    <?php $__currentLoopData = $detaildonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$datadetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td style="width:30px"><?php echo e(++$key); ?></td>
                                            <td style="width:100px"><?php echo e($datadetail->peruntukandonasi->namaperuntukandonasi); ?></td>
                                            <td style="width:100px;text-align:right"><?php echo e(number_format($datadetail->jumlah,0,',','.')); ?> <br/></td>
                                        </tr>    
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>   
                                <?php endif; ?>
                            </td>
                            <td style="text-align:right"><?php echo e(number_format($donasi->jumlahtotal,0,',','.')); ?>

                                    <br/><small><em><?php echo e($donasi->keterangan); ?></em></small> 
                                    <?php if($donasi->insidentil == 1): ?>
                                        <strong>(Donasi Insidentil)</strong>
                                    <?php endif; ?>
                                    <?php 
                                        $total += $donasi->jumlahtotal;
                                    ?>
                                    
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr class="bg-navy">
                            <td></td>
                            <td colspan="5" style="text-align:center"><strong>TOTAL</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                    </tr>  
                    

                </tbody>
        </table>
            


    <?php endif; ?>

    <!-- // === TAMPILKAN DATA KOTAK INFAQ YANG MENJADI TANGGUNGANNYA==============   -->
    <?php if(sizeof($datakotakinfaq)>0): ?>
        
        <h3>Data Kotak Infaq</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:30px">Kuitansi</th>
                        <th style="text-align:center;width:70px">Tanggal</th>
                        <th style="text-align:center;width:100px">Donatur</th>
                        <th style="text-align:center;width:100px">Amil Yang Mengambil</th>
                        <th style="text-align:center;width:150px">Total</th>
                    </tr>
                </thead>

                        <?php 
                            $total = 0;
                        ?>

                <tbody>
                    <?php $__currentLoopData = $datakotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e(config('app.kodekuitansi.trxkotakinfaq').$donasi->id); ?></td>
                            <td><?php echo e($donasi->tanggaldonasi); ?></td>
                            <td>(<?php echo e(config('app.kodedonatur').$donasi->donatur->id); ?>) <?php echo e($donasi->donatur->namadonatur); ?></td>
                            <td>(<?php echo e(config('app.kodeamil').$donasi->amil->id); ?>) <?php echo e($donasi->amil->namaamil); ?></td>
                            
                            <td style="text-align:right"><?php echo e(number_format($donasi->jumlahtotal,0,',','.')); ?>

                                    <br/><small><em><?php echo e($donasi->keterangan); ?></em></small> 
                                    <?php if($donasi->insidentil == 1): ?>
                                        <strong>(Donasi Insidentil)</strong>
                                    <?php endif; ?>
                                    <?php 
                                        $total += $donasi->jumlahtotal;
                                    ?>
                                    
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <tr class="bg-navy">
                            <td></td>
                            <td colspan="4" style="text-align:center"><strong>TOTAL</strong></td>
                            <td style="text-align:right"><?php echo e(number_format($total,0,',','.')); ?></td>
                    </tr>  
                    

                </tbody>
        </table>
            


    <?php endif; ?>

<?php endif; ?>


<!-- //========== JIKA TIPELAPORAN == 2 ========== -->
<!-- // TIPE LAPORAN DAFTAR DONATUR YANG SUDAH DAN BELUM JADI-->
<?php if($tipelaporan==3): ?>

    <!-- // === TAMPILKAN DATA DONATUR YANG MENJADI TANGGUNGANNYA==============   -->
    <?php if(sizeof($datadonatur)>0): ?>
        <h3>Data Donatur</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:40px">ID</th>
                        <th style="text-align:center;width:100px">Nama Donatur</th>
                        <th style="text-align:center;width:80px">Nomor Telepon</th>
                        <th style="text-align:center;width:150px">Alamat</th>
                        <th style="text-align:center;width:100px">Jenis Donatur</th>
                        <th style="text-align:center;width:300px">Status Terambil</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $datadonatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align:right"><?php echo e(++$key); ?></td>
                            <td style="text-align:center"><?php echo e(config('app.kodedonatur')); ?><?php echo e($donatur->id); ?></td>
                            <td><?php echo e($donatur->namadonatur); ?></td>
                            
                            <td><?php echo e($donatur->nomortelepondonatur); ?></td>
                            <td><?php echo e($donatur->alamatdonatur); ?></td>

                            <td>
                                <?php if($donatur->isdonaturrutin): ?>
                                    Donatur Rutin, 
                                <?php endif; ?>
                                <?php if($donatur->iskotakinfaq): ?>
                                    Kotak Infaq, 
                                <?php endif; ?>
                                <?php if($donatur->isdonaturinsidental): ?>
                                    Insidental, 
                                <?php endif; ?>
                            </td>

                            <td>
                                <table class="table">
                                <!-- // check apakah donatur id ada di dalam data transaksinya ada didalamnya sini -->
                                <?php $__currentLoopData = $datadonasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($donasi->donatur_id == $donatur->id): ?>
                                        <tr>
                                        <td>DONASI<a href="/trxdonasi/<?php echo e($donasi->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxdonasi')); ?><?php echo e($donasi->id); ?>)</a></td>
                                        <td><?php echo e($donasi->tanggaldonasi); ?></td> 
                                        <td><?php echo e($donasi->amil->namaamil); ?></td>
                                        <td><?php echo e(number_format($donasi->jumlahtotal,0,',','.')); ?></td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <!-- // check apakah donatur id ada di dalam data transaksinya ada didalamnya sini -->
                                <?php $__currentLoopData = $datakotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$kotakinfaq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($kotakinfaq->donatur_id == $donatur->id): ?>
                                        <tr>
                                        <td>KTKINFAQ<a href="/trxkotakinfaq/<?php echo e($kotakinfaq->id); ?>" target="_blank">(<?php echo e(config('app.kodekuitansi.trxkotakinfaq')); ?><?php echo e($kotakinfaq->id); ?>)</a></td>
                                        <td><?php echo e($kotakinfaq->tanggaldonasi); ?> </td>
                                        <td><?php echo e($kotakinfaq->amil->namaamil); ?> </td>
                                        <td> <?php echo e(number_format($kotakinfaq->jumlahtotal,0,',','.')); ?>   </td>
                                        </tr>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>
        <hr/>
        <br/>
    <?php endif; ?>




<?php endif; ?>


<!-- //========== JIKA TIPELAPORAN == 4 ========== -->
<!-- // TIPE LAPORAN TAMPILKAN DONATUR YANG JADI TANGGUNGAN -->
<!-- //========== JIKA TIPELAPORAN == 4 ========== -->
<?php if($tipelaporan==4): ?>

    <!-- // === TAMPILKAN DATA DONATUR RUTIN YANG MENJADI TANGGUNGANNYA==============   -->
    <?php if(sizeof($datadonaturrutin)>0): ?>
        <h3>Data Donatur Rutin</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">ID Donatur</th>
                        <th style="text-align:center;width:100px">Nama Donatur</th>
                        <th style="text-align:center;width:150px">Nomor Telepon</th>
                        <th style="text-align:center;width:150px">Alamat</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $datadonatur; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e(config('app.kodedonatur')); ?><?php echo e($donatur->id); ?></td>
                            <td><?php echo e($donatur->namadonatur); ?></td>
                            <td><?php echo e($donatur->nomortelepondonatur); ?></td>
                            <td><?php echo e($donatur->alamatdonatur); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>
        <hr/>
        <br/>
    <?php endif; ?>
        
    <!--    // === TAMPILKAN DATA DONATUR KOTAK INFAQ YANG MENJADI TANGGUNGANNYA============== -->
    <?php if(sizeof($datadonaturkotakinfaq)>0): ?>
        <h3>Data Donatur Kotak Infaq</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">ID Donatur</th>
                        <th style="text-align:center;width:100px">Nama Donatur</th>
                        <th style="text-align:center;width:150px">Nomor Telepon</th>
                        <th style="text-align:center;width:150px">Alamat</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $datadonaturkotakinfaq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e(config('app.kodedonatur')); ?><?php echo e($donatur->id); ?></td>
                            <td><?php echo e($donatur->namadonatur); ?></td>
                            <td><?php echo e($donatur->nomortelepondonatur); ?></td>
                            <td><?php echo e($donatur->alamatdonatur); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>
        <hr/>
        <br/>
    <?php endif; ?>
        
    <!-- // === TAMPILKAN DATA DONATUR INSIDENTAL YANG MENJADI TANGGUNGANNYA============== -->
    <?php if(sizeof($datadonaturinsidental)>0): ?>
        <h3>Data Donatur Insidental</h3>
        <table class="table table-striped table-bordered table-condensed">
                <thead class="bg-blue">
                    <tr>
                        <th style="text-align:center;width:30px">No.</th>
                        <th style="text-align:center;width:75px">ID Donatur</th>
                        <th style="text-align:center;width:100px">Nama Donatur</th>
                        <th style="text-align:center;width:150px">Nomor Telepon</th>
                        <th style="text-align:center;width:150px">Alamat</th>
                    </tr>
                </thead>

                <tbody>

                    <?php $__currentLoopData = $datadonaturinsidental; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$donatur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e(config('app.kodedonatur')); ?><?php echo e($donatur->id); ?></td>
                            <td><?php echo e($donatur->namadonatur); ?></td>
                            <td><?php echo e($donatur->nomortelepondonatur); ?></td>
                            <td><?php echo e($donatur->alamatdonatur); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
        </table>
        <hr/>
        <br/>
    <?php endif; ?>
        

    
<?php endif; ?>
<!-- //========== ENDIF TIPELAPORAN == 4 ========== -->


<?php $__env->stopSection(); ?>

<!-- //===========SCRIPT FOR THE FOOTER  ===========   -->
<?php $__env->startSection('footer-code'); ?>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.layoutblank', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>