<?php
//connect mysql database
$host = "localhost";
$user = "root";
$pass = "tonitegar";
$db = "coba1";
$con = mysqli_connect($host, $user, $pass, $db) or die("Error " . mysqli_error($con));
?>
