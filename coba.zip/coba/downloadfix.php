<?php
	$dir = "uploads/";
	if(!file_exists($dir.$_GET['filename'])){
		echo "Gagal download! File sudah tidak ada di folder";
		exit();
	} else {

		$name = $dir.$_GET['filename'];
		header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="'.basename($name).'"');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($name));
        flush(); // Flush system output buffer
        readfile($name);
        exit;

		/*
		
		header("Content-Type: octed/stream");
		header("Content-Disposition: attachment; filename=\"".$_GET['filename']."\"");
		header('Content-Length: ' . filesize($name));	//agar ketahuan ukuran filenya
		$fp = fopen($dir.$_GET['filename'], "r");
		$data = fread($fp, filesize($dir.$_GET['filename']));
		fclose($fp);
		print($data);
		*/
	}
?>